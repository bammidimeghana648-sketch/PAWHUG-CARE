import { CONDITION_MAX, type ReportDraft } from '@/lib/reports/reportModel';
import type { LocationDraft } from '@/lib/location';
import type { ScreeningCategory, SymptomId } from '@/lib/screening/symptoms';

export type CaseHandoff = {
  category: ScreeningCategory;
  symptoms: SymptomId[];
  conditionSummary: string;
  location: LocationDraft | null;
  photo: File | null;
  screenedAt: string;
};

type CaseHandoffInput = Omit<CaseHandoff, 'conditionSummary'> & {
  symptomLabels: string[];
  notes: string;
  concernLabel: string;
  notesLabel: string;
};

export function createCaseHandoff({ symptomLabels, notes, concernLabel, notesLabel, ...rest }: CaseHandoffInput): CaseHandoff {
  const lines = [`${concernLabel}: ${symptomLabels.join(', ')}.`];
  if (notes.trim()) lines.push(`${notesLabel}: ${notes.trim()}`);
  return { ...rest, conditionSummary: lines.join('\n').slice(0, CONDITION_MAX) };
}

export function draftFromCaseHandoff(handoff: CaseHandoff): ReportDraft {
  const location = handoff.location;
  return {
    animalCategory: handoff.category,
    conditionSummary: handoff.conditionSummary,
    locationText: location?.kind === 'manual' ? location.address : '',
    latitude: location?.kind === 'gps' ? location.latitude : null,
    longitude: location?.kind === 'gps' ? location.longitude : null,
    symptoms: handoff.symptoms,
  };
}
