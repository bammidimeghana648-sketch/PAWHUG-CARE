import type { TranslationKey } from '@/i18n/english';
import {
  SCREENING_CATEGORIES,
  URGENCY_ORDER,
  type ScreeningCategory,
  type SymptomId,
  type Urgency,
} from '@/lib/screening/symptoms';

export const REPORT_STATUSES = ['submitted', 'under_review', 'resolved'] as const;

export const RESCUE_PHOTO_BUCKET = 'rescue-photos';

export type ReportStatus = (typeof REPORT_STATUSES)[number];

export type RescueReport = {
  id: string;
  reference: string;
  animal_category: ScreeningCategory;
  condition_summary: string;
  location_text: string;
  latitude: number | null;
  longitude: number | null;
  status: ReportStatus;
  created_at: string;
  photo_path: string | null;
  screening_urgency: Urgency | null;
  screening_symptoms: SymptomId[];
  screened_at: string | null;
};

export type ReportDraft = {
  animalCategory: ScreeningCategory | '';
  conditionSummary: string;
  locationText: string;
  latitude: number | null;
  longitude: number | null;
  symptoms: SymptomId[];
};

export type ReportField = 'animalCategory' | 'conditionSummary' | 'locationText';

export const CONDITION_MIN = 10;
export const CONDITION_MAX = 500;
export const LOCATION_MIN = 3;
export const LOCATION_MAX = 200;

export function validateReportDraft(draft: ReportDraft): Partial<Record<ReportField, TranslationKey>> {
  const errors: Partial<Record<ReportField, TranslationKey>> = {};
  const category = draft.animalCategory;
  if (!SCREENING_CATEGORIES.some((item) => item.id === category)) {
    errors.animalCategory = 'report.errorCategory';
  }
  const condition = draft.conditionSummary.trim();
  if (condition.length < CONDITION_MIN || condition.length > CONDITION_MAX) {
    errors.conditionSummary = 'report.errorCondition';
  }
  const location = draft.locationText.trim();
  const hasGps = draft.latitude !== null && draft.longitude !== null;
  if (location.length > LOCATION_MAX || (!hasGps && location.length < LOCATION_MIN)) {
    errors.locationText = 'report.errorLocation';
  }
  return errors;
}

export function resolveReportLocation(draft: ReportDraft): string {
  const typed = draft.locationText.trim();
  if (typed) return typed;
  return `GPS ${draft.latitude?.toFixed(5)}, ${draft.longitude?.toFixed(5)}`;
}

const REPORT_ROW_KEYS = [
  'id',
  'reference',
  'animal_category',
  'condition_summary',
  'location_text',
  'latitude',
  'longitude',
  'status',
  'created_at',
  'photo_path',
  'screening_urgency',
  'screening_symptoms',
  'screened_at',
] as const;

export function isRescueReport(value: unknown): value is RescueReport {
  if (typeof value !== 'object' || value === null) return false;
  const row = value as Record<string, unknown>;
  return (
    REPORT_ROW_KEYS.every((key) => key in row) &&
    typeof row.id === 'string' &&
    typeof row.reference === 'string' &&
    typeof row.condition_summary === 'string' &&
    typeof row.location_text === 'string' &&
    typeof row.created_at === 'string' &&
    (row.photo_path === null || typeof row.photo_path === 'string') &&
    (row.screening_urgency === null || URGENCY_ORDER.includes(row.screening_urgency as Urgency)) &&
    Array.isArray(row.screening_symptoms) &&
    (row.screened_at === null || typeof row.screened_at === 'string') &&
    REPORT_STATUSES.includes(row.status as ReportStatus) &&
    SCREENING_CATEGORIES.some((item) => item.id === row.animal_category)
  );
}
