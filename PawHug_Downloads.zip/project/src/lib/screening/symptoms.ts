import type { TranslationKey } from '@/i18n/english';

export const SCREENING_CATEGORIES = [
  { id: 'dog', label: 'category.dog' },
  { id: 'cat', label: 'category.cat' },
  { id: 'cow', label: 'category.cow' },
  { id: 'buffalo', label: 'category.buffalo' },
  { id: 'pig', label: 'category.pig' },
  { id: 'bird', label: 'category.bird' },
  { id: 'other', label: 'category.other' },
] as const satisfies readonly { id: string; label: TranslationKey }[];

export type ScreeningCategory = (typeof SCREENING_CATEGORIES)[number]['id'];

export type Urgency = 'general' | 'vet' | 'urgent' | 'emergency';

export const URGENCY_ORDER: Urgency[] = ['general', 'vet', 'urgent', 'emergency'];

export type SymptomId =
  | 'severe_bleeding'
  | 'breathing'
  | 'collapse'
  | 'wound'
  | 'swelling'
  | 'skin'
  | 'hair_loss'
  | 'discharge'
  | 'walking'
  | 'weakness'
  | 'appetite'
  | 'behaviour'
  | 'other';

export type Symptom = {
  id: SymptomId;
  label: TranslationKey;
  urgency: Urgency;
  severeUrgency?: Urgency;
  concern: TranslationKey;
  infectionRisk: boolean;
};

export const SYMPTOMS: readonly Symptom[] = [
  {
    id: 'severe_bleeding',
    label: 'symptom.severe_bleeding',
    urgency: 'emergency',
    concern: 'symptom.severe_bleeding.concern',
    infectionRisk: false,
  },
  {
    id: 'breathing',
    label: 'symptom.breathing',
    urgency: 'emergency',
    concern: 'symptom.breathing.concern',
    infectionRisk: false,
  },
  {
    id: 'collapse',
    label: 'symptom.collapse',
    urgency: 'emergency',
    concern: 'symptom.collapse.concern',
    infectionRisk: false,
  },
  {
    id: 'wound',
    label: 'symptom.wound',
    urgency: 'urgent',
    concern: 'symptom.wound.concern',
    infectionRisk: true,
  },
  {
    id: 'swelling',
    label: 'symptom.swelling',
    urgency: 'vet',
    concern: 'symptom.swelling.concern',
    infectionRisk: false,
  },
  {
    id: 'skin',
    label: 'symptom.skin',
    urgency: 'vet',
    concern: 'symptom.skin.concern',
    infectionRisk: true,
  },
  {
    id: 'hair_loss',
    label: 'symptom.hair_loss',
    urgency: 'vet',
    concern: 'symptom.hair_loss.concern',
    infectionRisk: true,
  },
  {
    id: 'discharge',
    label: 'symptom.discharge',
    urgency: 'urgent',
    concern: 'symptom.discharge.concern',
    infectionRisk: true,
  },
  {
    id: 'walking',
    label: 'symptom.walking',
    urgency: 'vet',
    severeUrgency: 'urgent',
    concern: 'symptom.walking.concern',
    infectionRisk: false,
  },
  {
    id: 'weakness',
    label: 'symptom.weakness',
    urgency: 'vet',
    severeUrgency: 'urgent',
    concern: 'symptom.weakness.concern',
    infectionRisk: true,
  },
  {
    id: 'appetite',
    label: 'symptom.appetite',
    urgency: 'vet',
    concern: 'symptom.appetite.concern',
    infectionRisk: true,
  },
  {
    id: 'behaviour',
    label: 'symptom.behaviour',
    urgency: 'vet',
    concern: 'symptom.behaviour.concern',
    infectionRisk: false,
  },
  {
    id: 'other',
    label: 'symptom.other',
    urgency: 'general',
    concern: 'symptom.other.concern',
    infectionRisk: false,
  },
];
