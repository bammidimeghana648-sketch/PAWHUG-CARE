import type { TranslationKey } from '@/i18n/english';
import type { ScreeningCategory, SymptomId } from '@/lib/screening/symptoms';

export type ConditionGuide = {
  immediate: TranslationKey[];
  avoid: TranslationKey[];
  vet: TranslationKey[];
};

export const NORMAL_GUIDE: ConditionGuide = {
  immediate: [
    'guide.normal.immediate.1',
    'guide.normal.immediate.2',
    'guide.normal.immediate.3',
    'guide.normal.immediate.4',
  ],
  avoid: ['guide.normal.avoid.1', 'guide.normal.avoid.2', 'guide.normal.avoid.3'],
  vet: ['guide.normal.vet.1', 'guide.normal.vet.2', 'guide.normal.vet.3', 'guide.normal.vet.4'],
};

const SKIN: ConditionGuide = {
  immediate: [
    'guide.skin.immediate.1',
    'guide.skin.immediate.2',
    'guide.skin.immediate.3',
    'guide.skin.immediate.4',
  ],
  avoid: ['analysis.avoid.2', 'guide.skin.avoid.1'],
  vet: ['guide.skin.vet.1', 'guide.skin.vet.2', 'guide.skin.vet.3'],
};

const WOUND: ConditionGuide = {
  immediate: ['guide.wound.immediate.1', 'guide.wound.immediate.2', 'guide.wound.immediate.3', 'analysis.urgentExtra.1'],
  avoid: ['analysis.avoid.2', 'guide.wound.avoid.1'],
  vet: ['guide.wound.vet.1', 'guide.wound.vet.2', 'guide.wound.vet.3'],
};

const SWELLING: ConditionGuide = {
  immediate: ['guide.swelling.immediate.1', 'guide.swelling.immediate.2'],
  avoid: ['guide.swelling.avoid.1'],
  vet: ['guide.swelling.vet.1', 'guide.swelling.vet.2'],
};

const DISCHARGE: ConditionGuide = {
  immediate: ['guide.discharge.immediate.1', 'guide.discharge.immediate.2'],
  avoid: ['guide.discharge.avoid.1', 'guide.discharge.avoid.2'],
  vet: ['guide.discharge.vet.1', 'guide.discharge.vet.2', 'guide.discharge.vet.3'],
};

const BREATHING: ConditionGuide = {
  immediate: ['guide.breathing.immediate.1', 'guide.breathing.immediate.2'],
  avoid: ['guide.breathing.avoid.1'],
  vet: ['guide.breathing.vet.1', 'analysis.vet.2'],
};

const BLEEDING: ConditionGuide = {
  immediate: ['analysis.urgentExtra.1', 'guide.bleeding.immediate.1'],
  avoid: ['guide.bleeding.avoid.1'],
  vet: ['analysis.vet.1', 'guide.bleeding.vet.1'],
};

const COLLAPSE: ConditionGuide = {
  immediate: ['guide.collapse.immediate.1', 'guide.collapse.immediate.2'],
  avoid: ['guide.collapse.avoid.1', 'guide.collapse.avoid.2'],
  vet: ['analysis.vet.3'],
};

const WALKING: ConditionGuide = {
  immediate: ['guide.walking.immediate.1', 'guide.walking.immediate.2'],
  avoid: ['guide.walking.avoid.1'],
  vet: ['guide.walking.vet.1', 'guide.walking.vet.2'],
};

const ILLNESS: ConditionGuide = {
  immediate: ['guide.illness.immediate.1', 'analysis.general.3'],
  avoid: ['guide.illness.avoid.1', 'analysis.avoid.1'],
  vet: ['guide.illness.vet.1', 'analysis.vet.4'],
};

const OTHER: ConditionGuide = {
  immediate: ['analysis.general.1', 'analysis.general.2'],
  avoid: [],
  vet: ['guide.other.vet.1'],
};

export const BIRD_WALKING_GUIDE: ConditionGuide = {
  immediate: [
    'guide.walking.bird.immediate.1',
    'guide.walking.bird.immediate.2',
  ],
  avoid: ['guide.walking.bird.avoid.1', 'guide.walking.bird.avoid.2'],
  vet: ['guide.walking.bird.vet.1', 'guide.walking.bird.vet.2'],
};

export const UNCLEAR_GUIDE: ConditionGuide = {
  immediate: ['analysis.unclear.immediate.1', 'analysis.unclear.immediate.2'],
  avoid: [],
  vet: ['analysis.unclear.vet.1'],
};

export const GUIDE_BY_SYMPTOM: Record<SymptomId, ConditionGuide> = {
  severe_bleeding: BLEEDING,
  breathing: BREATHING,
  collapse: COLLAPSE,
  wound: WOUND,
  swelling: SWELLING,
  skin: SKIN,
  hair_loss: SKIN,
  discharge: DISCHARGE,
  walking: WALKING,
  weakness: ILLNESS,
  appetite: ILLNESS,
  behaviour: ILLNESS,
  other: OTHER,
};

export const BASELINE_AVOID: TranslationKey[] = ['analysis.avoid.1', 'analysis.avoid.3', 'analysis.avoid.4'];
export const BASELINE_VET: TranslationKey[] = ['analysis.vet.5', 'analysis.general.4'];

export const CATEGORY_IMMEDIATE: Record<ScreeningCategory, TranslationKey> = {
  dog: 'analysis.immediate.dog',
  cat: 'analysis.immediate.cat',
  cow: 'analysis.immediate.livestock',
  buffalo: 'analysis.immediate.livestock',
  pig: 'analysis.immediate.livestock',
  bird: 'analysis.immediate.bird',
  other: 'analysis.immediate.other',
};
