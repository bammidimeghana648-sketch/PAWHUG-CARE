import type { SymptomId } from '@/lib/screening/symptoms';

export type DetectedSymptom = { id: SymptomId; severe: boolean };

export type DescriptionReading = {
  detected: DetectedSymptom[];
  reassured: boolean;
};

const NEGATION = /\b(not|no|never|cannot|cant|unable|without|refus\w*|stopp?ed|lost|loss)\b|n't/;
const REASSURANCE = /\b(normal|normally|fine|well|healthy|good|okay|ok|playing|active|usual|usually|happy)\b/;

const SEVERE_MOBILITY =
  /\b(unable|cannot|cant|not able|no longer able)\s+(to\s+)?(stand|walk|get up|move|rise|use)\b|\bnot (able to )?(stand|get up)\b|\bdrag(s|ging|ged)?\b|\bnot (putting|bearing) (any )?weight\b|\bparaly\w*|\bhanging\b|\bdangling\b|\bdrooping wing\b|\bnot moving\b/;

type Rule = { id: SymptomId; pattern: RegExp; severePattern?: RegExp };

const RULES: Rule[] = [
  {
    id: 'severe_bleeding',
    pattern:
      /\b(severe|heavy|lots? of|massive|profuse|spurting|gushing|excessive)\b.{0,20}\b(bleed\w*|blood\w*)\b|\b(bleed\w*|blood\w*)\b.{0,25}\b(severe|heavy|a lot|lots|spurting|gushing|everywhere|won'?t stop|wont stop|not stopping|doesn'?t stop|does not stop)\b/,
  },
  {
    id: 'breathing',
    pattern:
      /\b(breathing|breath|breathe)\b.{0,20}\b(heavily|hard|difficult\w*|trouble|fast|rapid|noisy|laboured|labored|with (a )?(difficulty|trouble|effort))\b|\b(difficult\w*|trouble|struggl\w*|hard|heavy|fast|rapid|noisy|laboured|labored|effort)\b.{0,15}\b(breath\w*|breathe)\b|\bgasp\w*|\bwheez\w*|\bchoking\b|\bsuffocat\w*|\bshort of breath\b|\bcan'?t breathe\b|\bcannot breathe\b|\bcant breathe\b|\bunable to breathe\b|\bnot breathing\b|\bstopped breathing\b|\bpanting heavily\b|\bmouth open\w*.{0,10}\bbreath\w*/,
  },
  {
    id: 'collapse',
    pattern:
      /\b(collaps\w*|faint\w*|passed out|pass(ed)? out|unconscious|unresponsive|fell over|falls? over|seizure\w*|convuls\w*|not responding|won'?t respond)\b/,
  },
  {
    id: 'wound',
    pattern:
      /\b(wound\w*|injur\w*|cut|cuts|gash\w*|laceration\w*|bite[ds]?|bitten|torn|puncture\w*|stab\w*|hurt\w*|bleed\w*|blood\w*|bloody|open sore\w*)\b/,
  },
  {
    id: 'swelling',
    pattern: /\b(swell\w*|swollen|lump\w*|bulge\w*|puffy|inflam\w*)\b/,
  },
  {
    id: 'skin',
    pattern: /\b(skin|itch\w*|scratching|rash\w*|scab\w*|crust\w*|flak\w*|scal(y|ing)|hot spots?|dermat\w*)\b/,
  },
  {
    id: 'hair_loss',
    pattern:
      /\b(bald\w*|losing (its |his |her |their )?(hair|fur)|(hair|fur)\b.{0,15}\b(loss|falling|fell out|thinning|missing)|patch\w* (of )?(hair|fur)|shedding (a lot|heavily))\b/,
  },
  {
    id: 'discharge',
    pattern: /\b(discharg\w*|pus|runny|mucus|snot|ooz\w*|oozing|nasal|sticky eyes?|eyes? (are )?(running|weeping))\b/,
  },
  {
    id: 'walking',
    pattern:
      /\b(limp\w*|lame\w*|hobbl\w*|wobbl\w*|stagger\w*|stumbl\w*|drag\w*|tripp?ing|walks? (funny|oddly|strangely))\b|\b(not|cannot|can'?t|cant|unable|isn'?t|doesn'?t|won'?t|struggl\w*|difficult\w*|trouble|hard|no longer|not able)\b.{0,25}\b(walk\w*|stand\w*|mov\w*|rise|get up|bear\w*|put\w*|us\w*|lift\w*|hop\w*|perch\w*|grip\w*|climb\w*|fly\w*|flying)\b/,
    severePattern: SEVERE_MOBILITY,
  },
  {
    id: 'weakness',
    pattern:
      /\b(weak\w*|very tired|lethar\w*|listless|lifeless|floppy|no energy|low energy|not moving|unable to move|cannot move|can'?t move|isn'?t moving|not getting up|lying (down )?all day)\b/,
    severePattern: SEVERE_MOBILITY,
  },
  {
    id: 'appetite',
    pattern:
      /\b(not eating|isn'?t eating|wont eat|won'?t eat|doesn'?t eat|refus\w* (to )?(eat|food|feed|meal)|loss of appetite|no appetite|off (its|his|her) food|not drinking|stopp?ed eating|not interested in food|poor appetite|eating less|hardly eat\w*|barely eat\w*|lost (its|his|her) appetite)\b/,
  },
  {
    id: 'behaviour',
    pattern:
      /\b(aggress\w*|hiding|withdrawn|unusual(ly)? quiet|behav\w* (change|different|strange|odd)|acting (strange|odd|differently)|restless|agitat\w*|confus\w*|disorient\w*|growling|snapping)\b/,
  },
];

function splitClauses(text: string): string[] {
  return text.split(/[.,;!?\n]+|\bbut\b/).map((clause) => clause.trim()).filter(Boolean);
}

export function readDescription(text: string): DescriptionReading {
  const normalized = text.toLowerCase().replace(/[\u2018\u2019]/g, "'").replace(/\s+/g, ' ');
  const found = new Map<SymptomId, boolean>();
  let reassured = false;

  for (const clause of splitClauses(normalized)) {
    const negated = NEGATION.test(clause);
    if (REASSURANCE.test(clause) && !negated) {
      reassured = true;
    }
    for (const rule of RULES) {
      if (!rule.pattern.test(clause)) continue;
      if (REASSURANCE.test(clause) && !negated) continue;
      const severe = Boolean(rule.severePattern?.test(clause)) || found.get(rule.id) === true;
      found.set(rule.id, severe);
    }
  }

  return {
    detected: [...found].map(([id, severe]) => ({ id, severe })),
    reassured,
  };
}
