import type { TranslationKey } from '@/i18n/english';
import {
  BASELINE_AVOID,
  BASELINE_VET,
  BIRD_WALKING_GUIDE,
  CATEGORY_IMMEDIATE,
  GUIDE_BY_SYMPTOM,
  NORMAL_GUIDE,
  UNCLEAR_GUIDE,
} from '@/lib/screening/guidance';
import { readDescription, type DetectedSymptom } from '@/lib/screening/describeSymptoms';
import {
  SYMPTOMS,
  URGENCY_ORDER,
  type ScreeningCategory,
  type Symptom,
  type SymptomId,
  type Urgency,
} from '@/lib/screening/symptoms';

export type ScreeningResult = {
  urgency: Urgency;
  needsMoreInfo: boolean;
  symptomIds: SymptomId[];
  observations: TranslationKey[];
  concerns: TranslationKey[];
  immediateSteps: TranslationKey[];
  avoidSteps: TranslationKey[];
  isolation: TranslationKey;
  vetWarnings: TranslationKey[];
  safeApproach: TranslationKey[];
  categoryNote: TranslationKey;
  ownerNotes: string;
};

const CATEGORY_NOTES: Record<ScreeningCategory, TranslationKey> = {
  dog: 'analysis.category.dog',
  cat: 'analysis.category.cat',
  cow: 'analysis.category.cow',
  buffalo: 'analysis.category.buffalo',
  pig: 'analysis.category.pig',
  bird: 'analysis.category.bird',
  other: 'analysis.category.other',
};

const EMERGENCY_STEPS: TranslationKey[] = [
  'analysis.emergency.1',
  'analysis.emergency.2',
  'analysis.emergency.3',
  'analysis.emergency.4',
];

const NORMAL_SAFE_APPROACH: TranslationKey[] = ['analysis.safe.1', 'analysis.safe.2'];

const CONCERN_SAFE_APPROACH: TranslationKey[] = ['analysis.safe.1', 'analysis.safe.2', 'analysis.safe.3', 'analysis.safe.4'];

function unique<T>(items: T[]): T[] {
  return [...new Set(items)];
}

function isolationGuidance(category: ScreeningCategory, infectionRisk: boolean): TranslationKey {
  const outcome = infectionRisk ? 'infection' : 'clear';
  if (category === 'cow' || category === 'buffalo' || category === 'pig') {
    return `analysis.isolation.livestock.${outcome}`;
  }
  if (category === 'bird') {
    return `analysis.isolation.bird.${outcome}`;
  }
  return `analysis.isolation.other.${outcome}`;
}

function levelOf(symptom: Symptom, severe: boolean): Urgency {
  return severe && symptom.severeUrgency ? symptom.severeUrgency : symptom.urgency;
}

function highest(levels: Urgency[]): Urgency {
  return levels.reduce<Urgency>(
    (top, level) => (URGENCY_ORDER.indexOf(level) > URGENCY_ORDER.indexOf(top) ? level : top),
    'general',
  );
}

export function urgencyForSymptoms(selected: ReadonlySet<SymptomId>): Urgency {
  return highest(SYMPTOMS.filter((symptom) => selected.has(symptom.id)).map((symptom) => levelOf(symptom, false)));
}

function mergeFindings(selected: ReadonlySet<SymptomId>, detected: DetectedSymptom[]): Map<SymptomId, boolean> {
  const findings = new Map<SymptomId, boolean>();
  for (const id of selected) findings.set(id, false);
  for (const { id, severe } of detected) findings.set(id, (findings.get(id) ?? false) || severe);
  return findings;
}

function guideFor(category: ScreeningCategory, id: SymptomId) {
  if (category === 'bird' && id === 'walking') return BIRD_WALKING_GUIDE;
  return GUIDE_BY_SYMPTOM[id];
}

export function analyzeAnimal(
  category: ScreeningCategory,
  selected: ReadonlySet<SymptomId>,
  ownerNotes: string,
): ScreeningResult {
  const notes = ownerNotes.trim();
  const reading = readDescription(notes);
  const findings = mergeFindings(selected, reading.detected);
  const chosen = SYMPTOMS.filter((symptom) => findings.has(symptom.id));

  if (chosen.length === 0) {
    const needsMoreInfo = notes.length > 0 && !reading.reassured;
    if (needsMoreInfo) {
      return {
        urgency: 'general',
        needsMoreInfo: true,
        symptomIds: [],
        observations: [],
        concerns: [],
        immediateSteps: UNCLEAR_GUIDE.immediate,
        avoidSteps: BASELINE_AVOID,
        isolation: 'analysis.unclear.isolation',
        vetWarnings: UNCLEAR_GUIDE.vet,
        safeApproach: NORMAL_SAFE_APPROACH,
        categoryNote: CATEGORY_NOTES[category],
        ownerNotes: notes,
      };
    }
    return {
      urgency: 'general',
      needsMoreInfo: false,
      symptomIds: [],
      observations: [],
      concerns: [],
      immediateSteps: NORMAL_GUIDE.immediate,
      avoidSteps: NORMAL_GUIDE.avoid,
      isolation: 'analysis.isolation.none',
      vetWarnings: NORMAL_GUIDE.vet,
      safeApproach: NORMAL_SAFE_APPROACH,
      categoryNote: CATEGORY_NOTES[category],
      ownerNotes: notes,
    };
  }

  const urgency = highest(chosen.map((symptom) => levelOf(symptom, findings.get(symptom.id) === true)));
  const guides = unique(chosen.map((symptom) => guideFor(category, symptom.id)));
  const infectionRisk = chosen.some((symptom) => symptom.infectionRisk);
  const emergency = urgency === 'emergency';

  return {
    urgency,
    needsMoreInfo: false,
    symptomIds: chosen.map((symptom) => symptom.id),
    observations: chosen.map((symptom) => symptom.label),
    concerns: chosen.map((symptom) => symptom.concern),
    immediateSteps: unique([
      ...(emergency ? EMERGENCY_STEPS : []),
      CATEGORY_IMMEDIATE[category],
      ...guides.flatMap((guide) => guide.immediate),
    ]),
    avoidSteps: unique([...guides.flatMap((guide) => guide.avoid), ...BASELINE_AVOID]),
    isolation: isolationGuidance(category, infectionRisk),
    vetWarnings: unique([...guides.flatMap((guide) => guide.vet), ...BASELINE_VET]),
    safeApproach: CONCERN_SAFE_APPROACH,
    categoryNote: CATEGORY_NOTES[category],
    ownerNotes: notes,
  };
}
