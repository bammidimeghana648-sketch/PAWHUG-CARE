import { useCallback, useEffect, useState } from 'react';
import { ClipboardList, RefreshCw } from 'lucide-react';
import { useLanguage } from '@/i18n/LanguageContext';
import { isRescueReport, RESCUE_PHOTO_BUCKET, type RescueReport, type ReportStatus } from '@/lib/reports/reportModel';
import { supabase } from '@/lib/supabase';
import ReportStatusSummary from '@/components/ReportStatusSummary';
import ReportList from '@/components/ReportList';

type LoadState =
  | { status: 'loading' }
  | { status: 'error' }
  | { status: 'ready'; reports: RescueReport[]; photoUrls: Record<string, string> };

const REPORT_LIMIT = 500;
const SIGNED_URL_SECONDS = 60 * 60;

async function fetchPhotoUrls(reports: RescueReport[]): Promise<Record<string, string>> {
  const paths = reports.map((report) => report.photo_path).filter((path): path is string => path !== null);
  if (paths.length === 0) return {};

  const { data, error } = await supabase.storage.from(RESCUE_PHOTO_BUCKET).createSignedUrls(paths, SIGNED_URL_SECONDS);
  if (error || !Array.isArray(data)) return {};

  const urls: Record<string, string> = {};
  for (const item of data) {
    if (item.path && item.signedUrl) urls[item.path] = item.signedUrl;
  }
  return urls;
}

async function fetchReports(): Promise<LoadState> {
  const { data, error } = await supabase
    .from('rescue_reports')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(REPORT_LIMIT);

  if (error || !Array.isArray(data) || !data.every(isRescueReport)) {
    return { status: 'error' };
  }
  return { status: 'ready', reports: data, photoUrls: await fetchPhotoUrls(data) };
}

export default function ReportsPage() {
  const { t } = useLanguage();
  const [state, setState] = useState<LoadState>({ status: 'loading' });
  const [refreshing, setRefreshing] = useState(false);

  const load = useCallback(async () => {
    setRefreshing(true);
    setState(await fetchReports());
    setRefreshing(false);
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const counts: Record<ReportStatus, number> = { submitted: 0, under_review: 0, resolved: 0 };
  if (state.status === 'ready') {
    for (const report of state.reports) counts[report.status] += 1;
  }

  return (
    <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6 sm:py-14">
      <div className="animate-fadeUp mb-10 flex flex-col gap-6 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="inline-flex items-center gap-2 text-sm font-semibold text-cherry-400">
            <ClipboardList className="h-4 w-4" aria-hidden="true" />
            {t('reports.kicker')}
          </p>
          <h1 className="mt-3 text-3xl font-bold text-ivory sm:text-4xl">{t('reports.title')}</h1>
          <p className="mt-3 max-w-2xl text-muted">{t('reports.subtitle')}</p>
        </div>
        <button type="button" onClick={load} disabled={refreshing} className="btn-secondary shrink-0">
          <RefreshCw className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`} aria-hidden="true" />
          {t('reports.refresh')}
        </button>
      </div>

      {state.status === 'loading' && <p className="text-muted">{t('reports.loading')}</p>}

      {state.status === 'error' && (
        <p role="alert" className="rounded-xl border border-cherry-500/40 bg-cherry-600/10 px-4 py-3 text-sm text-cherry-300">
          {t('reports.errorLoad')}
        </p>
      )}

      {state.status === 'ready' && (
        <div className="space-y-8">
          <ReportStatusSummary total={state.reports.length} counts={counts} />
          <ReportList reports={state.reports} photoUrls={state.photoUrls} />
        </div>
      )}
    </div>
  );
}
