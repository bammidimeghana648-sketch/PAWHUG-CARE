import { useState } from 'react';
import { ArrowRight, Heart, PawPrint } from 'lucide-react';
import { useLanguage } from '@/i18n/LanguageContext';
import type { LanguageCode } from '@/i18n/languages';
import LanguageGrid from '@/components/LanguageGrid';
import Logo from '@/components/Logo';

export default function LanguageSelectPage() {
  const { setLanguage, t } = useLanguage();
  const [selected, setSelected] = useState<LanguageCode | null>(null);

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden px-4 py-12">
      <PawPrint className="pointer-events-none absolute left-[8%] top-[12%] h-16 w-16 text-violet-400/10 animate-drift" aria-hidden="true" />
      <Heart className="pointer-events-none absolute bottom-[10%] right-[8%] h-20 w-20 text-cherry-500/10 animate-drift" aria-hidden="true" />

      <section className="relative w-full max-w-4xl">
        <div className="animate-fadeUp flex flex-col items-center text-center">
          <Logo className="mb-6" />
          <h1 className="text-3xl font-bold leading-tight text-ivory sm:text-4xl">{t('lang.title')}</h1>
          <p className="mt-3 max-w-md text-base text-muted">{t('lang.subtitle')}</p>
        </div>

        <div className="mt-10">
          <LanguageGrid selected={selected} onSelect={setSelected} />
        </div>

        <div className="mt-10 flex flex-col items-center gap-4">
          <button
            type="button"
            onClick={() => selected && setLanguage(selected)}
            disabled={!selected}
            className="btn-primary min-w-[220px] text-lg"
          >
            {t('lang.continue')}
            <ArrowRight className="h-5 w-5" />
          </button>
          <p className="max-w-lg text-center text-sm text-muted">{t('lang.fallbackNote')}</p>
        </div>
      </section>
    </div>
  );
}
