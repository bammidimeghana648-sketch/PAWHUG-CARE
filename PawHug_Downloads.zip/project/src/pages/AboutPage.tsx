import { Heart, ShieldCheck } from 'lucide-react';
import { useLanguage } from '@/i18n/LanguageContext';
import Logo from '@/components/Logo';

export default function AboutPage() {
  const { t } = useLanguage();

  return (
    <div className="mx-auto max-w-3xl px-4 py-10 sm:px-6 sm:py-14">
      <div className="animate-fadeUp card flex flex-col items-center text-center sm:p-12">
        <Logo />
        <h1 className="mt-6 text-3xl font-bold text-ivory sm:text-4xl">{t('about.title')}</h1>
        <p className="mt-2 inline-flex items-center gap-2 text-sm font-semibold text-cherry-400">
          <Heart className="h-4 w-4 fill-current" aria-hidden="true" />
          {t('home.tagline')}
        </p>
        <p className="mt-6 leading-relaxed text-muted">{t('about.body')}</p>
        <p className="mt-8 flex items-center gap-2 rounded-2xl bg-emerald-400/10 px-4 py-3 text-sm font-semibold text-emerald-300">
          <ShieldCheck className="h-4 w-4 shrink-0" aria-hidden="true" />
          {t('home.disclaimer')}
        </p>
      </div>
    </div>
  );
}
