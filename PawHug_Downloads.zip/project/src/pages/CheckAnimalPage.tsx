import { useEffect, useRef, useState, type ReactNode } from 'react';
import { CheckCircle2, Circle, MapPin, Camera, Sparkles, Stethoscope } from 'lucide-react';
import { useLanguage } from '@/i18n/LanguageContext';
import type { TranslationKey } from '@/i18n/english';
import type { LocationDraft } from '@/lib/location';
import { analyzeAnimal, type ScreeningResult as Result } from '@/lib/screening/analyzeAnimal';
import { type ScreeningCategory, type SymptomId } from '@/lib/screening/symptoms';
import { createCaseHandoff, type CaseHandoff } from '@/lib/reports/caseHandoff';
import { useObjectUrl } from '@/hooks/useObjectUrl';
import PhotoUploader from '@/components/PhotoUploader';
import LocationPicker from '@/components/LocationPicker';
import ScreeningForm from '@/components/ScreeningForm';
import ScreeningResult from '@/components/ScreeningResult';

type StepProps = {
  number: number;
  icon: typeof Camera;
  titleKey: TranslationKey;
  done: boolean;
  children: ReactNode;
};

function Step({ number, icon: Icon, titleKey, done, children }: StepProps) {
  const { t } = useLanguage();
  return (
    <section className="card relative z-10 animate-fadeUp has-[[aria-expanded=true]]:z-30">
      <header className="mb-6 flex items-center gap-4">
        <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-white/10 text-ivory">
          <Icon className="h-6 w-6" aria-hidden="true" />
        </span>
        <div className="min-w-0 flex-1">
          <p className="text-xs font-semibold uppercase tracking-widest text-cherry-400">
            {t('check.stepLabel')} {number}
          </p>
          <h2 className="text-xl font-semibold text-ivory">{t(titleKey)}</h2>
        </div>
        {done ? (
          <CheckCircle2 className="h-6 w-6 shrink-0 text-emerald-300" aria-label="Completed" />
        ) : (
          <Circle className="h-6 w-6 shrink-0 text-muted/50" aria-hidden="true" />
        )}
      </header>
      {children}
    </section>
  );
}

type CheckAnimalPageProps = {
  onReportCase: (handoff: CaseHandoff) => void;
};

export default function CheckAnimalPage({ onReportCase }: CheckAnimalPageProps) {
  const { t } = useLanguage();
  const [photo, setPhoto] = useState<File | null>(null);
  const [location, setLocation] = useState<LocationDraft | null>(null);
  const [category, setCategory] = useState<ScreeningCategory>('other');
  const [selectedSymptoms, setSelectedSymptoms] = useState<Set<SymptomId>>(new Set());
  const [notes, setNotes] = useState('');
  const [result, setResult] = useState<Result | null>(null);
  const [screenedAt, setScreenedAt] = useState<string | null>(null);
  const [errorKey, setErrorKey] = useState<TranslationKey | null>(null);
  const photoUrl = useObjectUrl(photo);
  const resultRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (result) resultRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }, [result]);

  const clearResult = () => setResult(null);

  const toggleSymptom = (id: SymptomId) => {
    setSelectedSymptoms((current) => {
      const next = new Set(current);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
    clearResult();
  };

  const changePhoto = (next: File | null) => {
    setPhoto(next);
    clearResult();
  };

  const analyze = () => {
    if (!photo) {
      setErrorKey('screen.errorPhoto');
      return;
    }
    setErrorKey(null);
    setResult(analyzeAnimal(category, selectedSymptoms, notes));
    setScreenedAt(new Date().toISOString());
  };

  const reportCase = () => {
    if (!result || !screenedAt || !photo) return;
    onReportCase(
      createCaseHandoff({
        category,
        symptoms: result.symptomIds,
        symptomLabels: result.observations.map((key) => t(key)),
        notes,
        concernLabel: t('report.prefillConcernLabel'),
        notesLabel: t('report.prefillNotesLabel'),
        location,
        photo,
        screenedAt,
      }),
    );
  };

  return (
    <div className="mx-auto max-w-3xl px-4 py-10 sm:px-6 sm:py-14">
      <div className="animate-fadeUp mb-10">
        <p className="inline-flex items-center gap-2 text-sm font-semibold text-cherry-400">
          <Sparkles className="h-4 w-4" aria-hidden="true" />
          PawHug
        </p>
        <h1 className="mt-3 text-3xl font-bold text-ivory sm:text-4xl">{t('check.title')}</h1>
        <p className="mt-3 max-w-2xl text-muted">{t('check.subtitle')}</p>
      </div>

      <div className="space-y-6">
        <Step number={1} icon={Camera} titleKey="check.step2" done={photo !== null}>
          <PhotoUploader file={photo} previewUrl={photoUrl} onSelect={changePhoto} onRemove={() => changePhoto(null)} />
        </Step>

        <Step number={2} icon={MapPin} titleKey="check.step3" done={location !== null}>
          <p className="mb-4 text-sm text-muted">{t('check.optional')}</p>
          <LocationPicker location={location} onChange={setLocation} />
        </Step>

        <Step number={3} icon={Stethoscope} titleKey="screen.title" done={result !== null}>
          <ScreeningForm
            category={category}
            onCategoryChange={(next) => {
              setCategory(next);
              clearResult();
            }}
            selected={selectedSymptoms}
            onToggleSymptom={toggleSymptom}
            notes={notes}
            onNotesChange={(next) => {
              setNotes(next);
              clearResult();
            }}
            errorKey={errorKey}
            onAnalyze={analyze}
          />
        </Step>

        {result && (
          <div ref={resultRef} className="scroll-mt-28">
            <ScreeningResult result={result} photoUrl={photoUrl} onReportCase={reportCase} />
          </div>
        )}
      </div>
    </div>
  );
}
