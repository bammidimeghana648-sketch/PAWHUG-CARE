import { useState } from 'react';
import { FilePenLine, Sparkles } from 'lucide-react';
import { useLanguage } from '@/i18n/LanguageContext';
import type { CaseHandoff } from '@/lib/reports/caseHandoff';
import type { RescueReport } from '@/lib/reports/reportModel';
import ReportForm from '@/components/ReportForm';
import ReportConfirmation from '@/components/ReportConfirmation';

type ReportPageProps = {
  handoff: CaseHandoff | null;
};

export default function ReportPage({ handoff }: ReportPageProps) {
  const { t } = useLanguage();
  const [submitted, setSubmitted] = useState<RescueReport | null>(null);
  const [prefill, setPrefill] = useState<CaseHandoff | null>(handoff);

  return (
    <div className="mx-auto max-w-3xl px-4 py-10 sm:px-6 sm:py-14">
      <div className="animate-fadeUp mb-10">
        <p className="inline-flex items-center gap-2 text-sm font-semibold text-cherry-400">
          <Sparkles className="h-4 w-4" aria-hidden="true" />
          PawHug
        </p>
        <h1 className="mt-3 text-3xl font-bold text-ivory sm:text-4xl">{t('report.title')}</h1>
        <p className="mt-3 max-w-2xl text-muted">{t('report.subtitle')}</p>
      </div>

      <section className="card animate-fadeUp">
        {submitted ? (
          <ReportConfirmation report={submitted} onReportAnother={() => setSubmitted(null)} />
        ) : (
          <>
            <header className="mb-8 flex items-center gap-4">
              <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-white/10 text-ivory">
                <FilePenLine className="h-6 w-6" aria-hidden="true" />
              </span>
              <h2 className="text-xl font-semibold text-ivory">{t('report.formTitle')}</h2>
            </header>
            <ReportForm
              prefill={prefill}
              onSubmitted={(report) => {
                setPrefill(null);
                setSubmitted(report);
              }}
            />
          </>
        )}
      </section>
    </div>
  );
}
