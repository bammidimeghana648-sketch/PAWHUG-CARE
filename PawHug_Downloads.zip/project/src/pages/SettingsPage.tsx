import { useState } from 'react';
import { CheckCircle2, Globe } from 'lucide-react';
import { useLanguage } from '@/i18n/LanguageContext';
import type { LanguageCode } from '@/i18n/languages';
import LanguageGrid from '@/components/LanguageGrid';

export default function SettingsPage() {
  const { language, setLanguage, t } = useLanguage();
  const [justSaved, setJustSaved] = useState(false);

  const handleSelect = (code: LanguageCode) => {
    setLanguage(code);
    setJustSaved(true);
  };

  return (
    <div className="mx-auto max-w-4xl px-4 py-10 sm:px-6 sm:py-14">
      <div className="animate-fadeUp mb-10">
        <h1 className="text-3xl font-bold text-ivory sm:text-4xl">{t('settings.title')}</h1>
        <p className="mt-3 text-muted">{t('settings.subtitle')}</p>
      </div>

      <section className="card animate-fadeUp">
        <div className="mb-6 flex items-center gap-4">
          <span className="grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br from-violet-500/30 to-wine-600/40 text-violet-300">
            <Globe className="h-6 w-6" aria-hidden="true" />
          </span>
          <div>
            <h2 className="text-xl font-semibold text-ivory">{t('settings.language')}</h2>
            <p className="text-sm text-muted">{t('settings.languageHelp')}</p>
          </div>
        </div>

        <LanguageGrid selected={language} onSelect={handleSelect} />

        <p role="status" className="mt-6 flex min-h-6 items-center gap-2 text-sm font-semibold text-emerald-300">
          {justSaved && (
            <>
              <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
              {t('settings.saved')}
            </>
          )}
        </p>
      </section>
    </div>
  );
}
