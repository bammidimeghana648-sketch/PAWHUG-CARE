import { ArrowRight, Camera, Heart, MapPin, PawPrint, Search, ShieldCheck } from 'lucide-react';
import { useLanguage } from '@/i18n/LanguageContext';
import type { TranslationKey } from '@/i18n/english';
import type { Route } from '@/hooks/useHashRoute';
import Logo from '@/components/Logo';

type HomePageProps = {
  onNavigate: (route: Route) => void;
};

const STEPS: { icon: typeof Search; titleKey: TranslationKey; bodyKey: TranslationKey }[] = [
  { icon: Search, titleKey: 'home.step1Title', bodyKey: 'home.step1Body' },
  { icon: Camera, titleKey: 'home.step2Title', bodyKey: 'home.step2Body' },
  { icon: MapPin, titleKey: 'home.step3Title', bodyKey: 'home.step3Body' },
];

export default function HomePage({ onNavigate }: HomePageProps) {
  const { t } = useLanguage();

  const scrollToHowItWorks = () => {
    document.getElementById('how-it-works')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  return (
    <div className="mx-auto max-w-6xl px-4 sm:px-6">
      <section className="grid items-center gap-12 py-12 md:grid-cols-2 md:py-20">
        <div className="animate-fadeUp">
          <Logo className="mb-6" />
          <p className="inline-flex items-center gap-2 rounded-full border border-cherry-500/30 bg-cherry-600/10 px-4 py-1.5 text-sm font-semibold text-cherry-400">
            <Heart className="h-4 w-4 fill-current animate-heartbeat" aria-hidden="true" />
            {t('home.tagline')}
          </p>
          <h1 className="mt-5 text-4xl font-bold leading-[1.15] text-ivory sm:text-5xl">{t('home.title')}</h1>
          <p className="mt-5 max-w-xl text-lg leading-relaxed text-muted">{t('home.intro')}</p>

          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <button type="button" onClick={() => onNavigate('check')} className="btn-primary">
              <PawPrint className="h-5 w-5" />
              {t('home.checkButton')}
              <ArrowRight className="h-5 w-5" />
            </button>
            <button type="button" onClick={scrollToHowItWorks} className="btn-secondary">
              {t('home.howButton')}
            </button>
          </div>
        </div>

        <div className="relative animate-fadeUp [animation-delay:150ms]">
          <div className="absolute -inset-4 rounded-[2.5rem] bg-gradient-to-br from-cherry-600/30 via-wine-600/20 to-navy-500/30 blur-2xl" aria-hidden="true" />
          <img
            src="https://images.pexels.com/photos/37891869/pexels-photo-37891869.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
            alt="A cat and a fluffy dog sitting together in a field of daisies"
            className="relative aspect-[4/3] w-full rounded-[2rem] border border-white/10 object-cover shadow-2xl shadow-black/50"
            loading="eager"
          />
          <div className="absolute -bottom-5 left-4 flex items-center gap-3 rounded-2xl border border-white/10 bg-night-800/95 px-4 py-3 shadow-xl backdrop-blur sm:left-8">
            <ShieldCheck className="h-6 w-6 text-emerald-300" aria-hidden="true" />
            <p className="text-sm font-semibold text-ivory">{t('home.badge')}</p>
          </div>
        </div>
      </section>

      <section id="how-it-works" className="scroll-mt-28 py-12">
        <h2 className="text-center text-3xl font-bold text-ivory">{t('home.howTitle')}</h2>
        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {STEPS.map((step, index) => (
            <article key={step.titleKey} className="card animate-fadeUp transition duration-300 hover:-translate-y-1 hover:border-violet-300/40" style={{ animationDelay: `${index * 120}ms` }}>
              <span className="grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-violet-500/30 to-wine-600/40 text-violet-300">
                <step.icon className="h-7 w-7" aria-hidden="true" />
              </span>
              <p className="mt-6 text-sm font-semibold tracking-widest text-cherry-400">0{index + 1}</p>
              <h3 className="mt-2 text-xl font-semibold text-ivory">{t(step.titleKey)}</h3>
              <p className="mt-3 leading-relaxed text-muted">{t(step.bodyKey)}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="my-12 overflow-hidden rounded-[2rem] border border-white/10 bg-gradient-to-br from-wine-700/60 via-night-800 to-navy-700/60 p-8 shadow-2xl sm:p-12">
        <div className="grid items-center gap-8 md:grid-cols-[1.2fr_1fr]">
          <div>
            <h2 className="text-3xl font-bold text-ivory">{t('home.helpTitle')}</h2>
            <p className="mt-4 leading-relaxed text-ivory/80">{t('home.helpBody')}</p>
            <button type="button" onClick={() => onNavigate('check')} className="btn-primary mt-8">
              {t('home.checkButton')}
              <ArrowRight className="h-5 w-5" />
            </button>
          </div>
          <div className="flex justify-center">
            <img
              src="/image.png"
              alt=""
              aria-hidden="true"
              className="h-56 w-56 rounded-[2rem] bg-white object-contain p-4 shadow-2xl animate-drift"
            />
          </div>
        </div>
      </section>

      <p className="pb-12 text-center text-sm leading-relaxed text-muted">{t('home.disclaimer')}</p>
    </div>
  );
}
