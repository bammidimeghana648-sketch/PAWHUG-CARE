import type { TranslationKey } from './english';
import type { LanguageCode } from './languages';
import { bn } from './locales/bn';
import { gu } from './locales/gu';
import { hi } from './locales/hi';
import { kn } from './locales/kn';
import { ml } from './locales/ml';
import { mr } from './locales/mr';
import { ta } from './locales/ta';
import { or } from './locales/or';
import { pa } from './locales/pa';
import { te } from './locales/te';
import { ur } from './locales/ur';

export const translations: Partial<Record<LanguageCode, Partial<Record<TranslationKey, string>>>> = {
  te,
  hi,
  ta,
  kn,
  ml,
  mr,
  bn,
  gu,
  pa,
  ur,
  or,
};
