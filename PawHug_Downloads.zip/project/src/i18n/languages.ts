export const LANGUAGES = [
  { code: 'en', name: 'English', nativeName: 'English', hasTranslation: true },
  { code: 'te', name: 'Telugu', nativeName: 'తెలుగు', hasTranslation: true },
  { code: 'hi', name: 'Hindi', nativeName: 'हिन्दी', hasTranslation: true },
  { code: 'ta', name: 'Tamil', nativeName: 'தமிழ்', hasTranslation: true },
  { code: 'kn', name: 'Kannada', nativeName: 'ಕನ್ನಡ', hasTranslation: true },
  { code: 'ml', name: 'Malayalam', nativeName: 'മലയാളം', hasTranslation: true },
  { code: 'mr', name: 'Marathi', nativeName: 'मराठी', hasTranslation: true },
  { code: 'bn', name: 'Bengali', nativeName: 'বাংলা', hasTranslation: true },
  { code: 'gu', name: 'Gujarati', nativeName: 'ગુજરાતી', hasTranslation: true },
  { code: 'pa', name: 'Punjabi', nativeName: 'ਪੰਜਾਬੀ', hasTranslation: true },
  { code: 'ur', name: 'Urdu', nativeName: 'اردو', hasTranslation: true },
  { code: 'or', name: 'Odia', nativeName: 'ଓଡ଼ିଆ', hasTranslation: true },
] as const;

export type LanguageCode = (typeof LANGUAGES)[number]['code'];

export const LANGUAGE_STORAGE_KEY = 'pawhug.language';

export function isLanguageCode(value: unknown): value is LanguageCode {
  return LANGUAGES.some((language) => language.code === value);
}
