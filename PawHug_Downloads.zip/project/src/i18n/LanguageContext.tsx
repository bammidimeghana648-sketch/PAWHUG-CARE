import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from 'react';
import { en, type TranslationKey } from './english';
import { translations } from './translations';
import { LANGUAGE_STORAGE_KEY, isLanguageCode, type LanguageCode } from './languages';

type LanguageContextValue = {
  language: LanguageCode | null;
  setLanguage: (code: LanguageCode) => void;
  t: (key: TranslationKey) => string;
};

const LanguageContext = createContext<LanguageContextValue | null>(null);

function readStoredLanguage(): LanguageCode | null {
  try {
    const stored = window.localStorage.getItem(LANGUAGE_STORAGE_KEY);
    return isLanguageCode(stored) ? stored : null;
  } catch {
    return null;
  }
}

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState<LanguageCode | null>(readStoredLanguage);

  const setLanguage = useCallback((code: LanguageCode) => {
    try {
      window.localStorage.setItem(LANGUAGE_STORAGE_KEY, code);
    } catch {
      // Storage can be blocked by the browser; the choice still applies for this visit.
    }
    setLanguageState(code);
  }, []);

  const value = useMemo<LanguageContextValue>(() => {
    const dictionary = (language && translations[language]) || {};
    return {
      language,
      setLanguage,
      t: (key) => dictionary[key] ?? en[key],
    };
  }, [language, setLanguage]);

  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used inside LanguageProvider');
  }
  return context;
}
