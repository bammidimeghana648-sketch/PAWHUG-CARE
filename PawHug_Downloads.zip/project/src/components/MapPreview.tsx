import { ExternalLink, MapPin } from 'lucide-react';
import { googleDirectionsUrl } from '@/lib/location';

type MapPreviewProps = {
  latitude: number;
  longitude: number;
};

export default function MapPreview({ latitude, longitude }: MapPreviewProps) {
  return (
    <div className="flex flex-col items-start gap-4 rounded-2xl border border-white/10 bg-night-900/60 p-5 sm:flex-row sm:items-center sm:justify-between">
      <div className="flex items-center gap-3">
        <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-cherry-600/20 text-cherry-300">
          <MapPin className="h-5 w-5" aria-hidden="true" />
        </span>
        <p className="text-sm text-muted">
          Pinned at <span className="font-mono text-ivory">{latitude.toFixed(5)}, {longitude.toFixed(5)}</span>
        </p>
      </div>
      <a
        href={googleDirectionsUrl(latitude, longitude)}
        target="_blank"
        rel="noopener noreferrer"
        className="btn-secondary"
      >
        <ExternalLink className="h-4 w-4" aria-hidden="true" />
        View on Google Maps
      </a>
    </div>
  );
}
