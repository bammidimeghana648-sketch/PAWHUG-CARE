import { useEffect, useRef, useState } from 'react';
import { Camera, LoaderCircle, X } from 'lucide-react';
import { useLanguage } from '@/i18n/LanguageContext';
import type { TranslationKey } from '@/i18n/english';

type CameraCaptureProps = {
  onCapture: (file: File) => void;
  onClose: () => void;
};

export default function CameraCapture({ onCapture, onClose }: CameraCaptureProps) {
  const { t } = useLanguage();
  const videoRef = useRef<HTMLVideoElement>(null);
  const [ready, setReady] = useState(false);
  const [errorKey, setErrorKey] = useState<TranslationKey | null>(null);

  useEffect(() => {
    let cancelled = false;
    let stream: MediaStream | null = null;

    navigator.mediaDevices
      .getUserMedia({ video: { facingMode: { ideal: 'environment' } }, audio: false })
      .then((media) => {
        if (cancelled) {
          media.getTracks().forEach((track) => track.stop());
          return;
        }
        stream = media;
        if (videoRef.current) {
          videoRef.current.srcObject = media;
          void videoRef.current.play();
        }
        setReady(true);
      })
      .catch((cause: unknown) => {
        if (cancelled) return;
        const denied = cause instanceof DOMException && cause.name === 'NotAllowedError';
        setErrorKey(denied ? 'check.cameraDenied' : 'check.cameraUnavailable');
      });

    return () => {
      cancelled = true;
      stream?.getTracks().forEach((track) => track.stop());
    };
  }, []);

  useEffect(() => {
    const handleKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [onClose]);

  const capture = () => {
    const video = videoRef.current;
    if (!video || video.videoWidth === 0) return;

    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const context = canvas.getContext('2d');
    if (!context) {
      setErrorKey('check.cameraUnavailable');
      return;
    }
    context.drawImage(video, 0, 0, canvas.width, canvas.height);
    canvas.toBlob(
      (blob) => {
        if (!blob) {
          setErrorKey('check.cameraUnavailable');
          return;
        }
        onCapture(new File([blob], `photo-${Date.now()}.jpg`, { type: 'image/jpeg' }));
      },
      'image/jpeg',
      0.92,
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-night-900/80 p-4 backdrop-blur-sm">
      <div role="dialog" aria-modal="true" aria-labelledby="camera-title" className="animate-fadeUp w-full max-w-xl space-y-5 rounded-3xl border border-white/10 bg-night-800 p-5 shadow-2xl sm:p-6">
        <div className="flex items-center justify-between gap-3">
          <h2 id="camera-title" className="text-lg font-semibold text-ivory">
            {t('check.cameraTitle')}
          </h2>
          <button type="button" onClick={onClose} aria-label={t('check.cameraClose')} className="grid h-9 w-9 place-items-center rounded-full bg-white/10 text-ivory transition hover:bg-white/20">
            <X className="h-4 w-4" aria-hidden="true" />
          </button>
        </div>

        <div className="relative aspect-video overflow-hidden rounded-2xl bg-black">
          <video ref={videoRef} playsInline muted className="h-full w-full object-cover" />
          {!ready && !errorKey && (
            <div className="absolute inset-0 grid place-items-center text-sm text-muted">
              <span className="inline-flex items-center gap-2">
                <LoaderCircle className="h-4 w-4 animate-spin" aria-hidden="true" />
                {t('check.cameraStarting')}
              </span>
            </div>
          )}
        </div>

        {errorKey && (
          <p role="alert" className="rounded-xl border border-cherry-500/40 bg-cherry-600/10 px-4 py-3 text-sm text-cherry-300">
            {t(errorKey)}
          </p>
        )}

        <div className="flex flex-col gap-3 sm:flex-row">
          <button type="button" onClick={capture} disabled={!ready} className="btn-primary">
            <Camera className="h-5 w-5" aria-hidden="true" />
            {t('check.cameraCapture')}
          </button>
          <button type="button" onClick={onClose} className="btn-secondary">
            {t('check.cameraClose')}
          </button>
        </div>
      </div>
    </div>
  );
}
