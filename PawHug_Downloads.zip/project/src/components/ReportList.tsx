import { ExternalLink, MapPin } from 'lucide-react';
import { useLanguage } from '@/i18n/LanguageContext';
import { SCREENING_CATEGORIES } from '@/lib/screening/symptoms';
import { googleMapsPointUrl } from '@/lib/location';
import type { RescueReport } from '@/lib/reports/reportModel';
import ReportStatusBadge from '@/components/ReportStatusBadge';
import { URGENCY_KEYS, URGENCY_STYLES } from '@/components/ScreeningResult';

type ReportListProps = {
  reports: RescueReport[];
  photoUrls: Record<string, string>;
};

export default function ReportList({ reports, photoUrls }: ReportListProps) {
  const { t, language } = useLanguage();

  if (reports.length === 0) {
    return (
      <div className="card text-center">
        <p className="text-ivory">{t('reports.empty')}</p>
        <p className="mt-2 text-sm text-muted">{t('reports.emptyHint')}</p>
      </div>
    );
  }

  const dateFormat = new Intl.DateTimeFormat(language ?? undefined, { dateStyle: 'medium', timeStyle: 'short' });

  return (
    <ul className="space-y-4">
      {reports.map((report) => {
        const categoryKey = SCREENING_CATEGORIES.find((item) => item.id === report.animal_category)?.label;
        const categoryLabel = categoryKey ? t(categoryKey) : '';
        const photoUrl = report.photo_path ? photoUrls[report.photo_path] : undefined;
        return (
          <li key={report.id} className="card overflow-hidden p-0">
            {photoUrl && (
              <img
                src={photoUrl}
                alt={t('reports.photoAlt')}
                loading="lazy"
                className="h-56 w-full object-cover sm:h-64"
              />
            )}
            <div className="p-5 sm:p-6">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <p className="font-mono text-sm font-semibold tracking-wider text-ivory">{report.reference}</p>
                <div className="flex flex-wrap items-center gap-2">
                  {report.screening_urgency && (
                    <span className={`rounded-full border px-3 py-1 text-xs font-semibold ${URGENCY_STYLES[report.screening_urgency]}`}>
                      {t(URGENCY_KEYS[report.screening_urgency])}
                    </span>
                  )}
                  <ReportStatusBadge status={report.status} />
                </div>
              </div>
              <div className="mt-4 space-y-2">
                <p className="text-lg font-semibold text-ivory">{categoryLabel}</p>
                <p className="text-sm leading-relaxed text-muted">{report.condition_summary}</p>
                <p className="flex items-start gap-2 text-sm text-muted">
                  <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-cherry-400" aria-hidden="true" />
                  <span>{report.location_text}</span>
                </p>
                {report.latitude !== null && report.longitude !== null && (
                  <a
                    href={googleMapsPointUrl(report.latitude, report.longitude)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="ml-6 inline-flex items-center gap-1.5 text-sm font-semibold text-cherry-300 underline-offset-4 hover:underline"
                  >
                    <ExternalLink className="h-3.5 w-3.5" aria-hidden="true" />
                    {t('reports.viewMap')}
                  </a>
                )}
              </div>
              <p className="mt-4 border-t border-white/10 pt-3 text-xs text-muted">
                {t('reports.reportedOn')} {dateFormat.format(new Date(report.created_at))}
              </p>
            </div>
          </li>
        );
      })}
    </ul>
  );
}
