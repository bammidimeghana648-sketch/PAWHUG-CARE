import { ArrowRight, CheckCircle2, RotateCcw } from 'lucide-react';
import { useLanguage } from '@/i18n/LanguageContext';
import type { RescueReport } from '@/lib/reports/reportModel';
import ReportStatusBadge from '@/components/ReportStatusBadge';

type ReportConfirmationProps = {
  report: RescueReport;
  onReportAnother: () => void;
};

export default function ReportConfirmation({ report, onReportAnother }: ReportConfirmationProps) {
  const { t } = useLanguage();

  return (
    <div className="animate-fadeUp space-y-7 text-center sm:text-left">
      <div className="mx-auto grid h-16 w-16 place-items-center rounded-2xl bg-emerald-400/15 text-emerald-200 sm:mx-0">
        <CheckCircle2 className="h-9 w-9" aria-hidden="true" />
      </div>
      <div>
        <h2 className="text-2xl font-bold text-ivory">{t('report.confirmTitle')}</h2>
        <p className="mt-2 text-muted">{t('report.confirmBody')}</p>
      </div>

      <div className="rounded-2xl border border-white/10 bg-night-900/60 p-5">
        <p className="text-xs font-semibold uppercase tracking-widest text-muted">{t('report.referenceLabel')}</p>
        <p className="mt-2 font-mono text-3xl font-bold tracking-wider text-ivory">{report.reference}</p>
        <div className="mt-4 flex flex-wrap items-center gap-3 sm:justify-start">
          <ReportStatusBadge status={report.status} />
          <span className="text-xs text-muted">{t('report.referenceHint')}</span>
        </div>
      </div>

      <div className="flex flex-col gap-3 sm:flex-row">
        <a href="#reports" className="btn-primary">
          {t('report.viewCases')}
          <ArrowRight className="h-4 w-4" aria-hidden="true" />
        </a>
        <button type="button" onClick={onReportAnother} className="btn-secondary">
          <RotateCcw className="h-4 w-4" aria-hidden="true" />
          {t('report.reportAnother')}
        </button>
      </div>
    </div>
  );
}
