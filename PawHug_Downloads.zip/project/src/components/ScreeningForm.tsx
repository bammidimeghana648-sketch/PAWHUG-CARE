import { Activity } from 'lucide-react';
import { useLanguage } from '@/i18n/LanguageContext';
import type { TranslationKey } from '@/i18n/english';
import { SCREENING_CATEGORIES, SYMPTOMS, type ScreeningCategory, type SymptomId } from '@/lib/screening/symptoms';

const MAX_NOTES_LENGTH = 500;

type ScreeningFormProps = {
  category: ScreeningCategory;
  onCategoryChange: (category: ScreeningCategory) => void;
  selected: ReadonlySet<SymptomId>;
  onToggleSymptom: (id: SymptomId) => void;
  notes: string;
  onNotesChange: (notes: string) => void;
  errorKey: TranslationKey | null;
  onAnalyze: () => void;
};

export default function ScreeningForm({
  category,
  onCategoryChange,
  selected,
  onToggleSymptom,
  notes,
  onNotesChange,
  errorKey,
  onAnalyze,
}: ScreeningFormProps) {
  const { t } = useLanguage();

  return (
    <div className="space-y-8">
      <div>
        <label htmlFor="screening-category" className="mb-2 block text-sm font-semibold text-ivory">
          {t('screen.categoryLabel')}
        </label>
        <select
          id="screening-category"
          value={category}
          onChange={(event) => onCategoryChange(event.target.value as ScreeningCategory)}
          className="field"
        >
          {SCREENING_CATEGORIES.map((item) => (
            <option key={item.id} value={item.id} className="bg-night-900">
              {t(item.label)}
            </option>
          ))}
        </select>
      </div>

      <fieldset>
        <legend className="text-sm font-semibold text-ivory">{t('screen.symptomsLabel')}</legend>
        <p className="mt-1 text-sm text-muted">{t('screen.symptomsHelp')}</p>
        <div className="mt-4 grid gap-2 sm:grid-cols-2">
          {SYMPTOMS.map((symptom) => {
            const checked = selected.has(symptom.id);
            return (
              <label
                key={symptom.id}
                className={`flex cursor-pointer items-start gap-3 rounded-2xl border p-3.5 text-sm transition duration-200 ${
                  checked
                    ? 'border-cherry-400/60 bg-cherry-600/15 text-ivory'
                    : 'border-white/10 bg-night-900/60 text-muted hover:border-white/25 hover:text-ivory'
                }`}
              >
                <input
                  type="checkbox"
                  checked={checked}
                  onChange={() => onToggleSymptom(symptom.id)}
                  className="mt-0.5 h-4 w-4 shrink-0 accent-cherry-500"
                />
                <span className="leading-snug">{t(symptom.label)}</span>
              </label>
            );
          })}
        </div>
      </fieldset>

      <div>
        <label htmlFor="screening-notes" className="mb-2 block text-sm font-semibold text-ivory">
          {t('screen.notesLabel')}
        </label>
        <textarea
          id="screening-notes"
          rows={3}
          value={notes}
          maxLength={MAX_NOTES_LENGTH}
          onChange={(event) => onNotesChange(event.target.value)}
          placeholder={t('screen.notesPlaceholder')}
          className="field resize-y"
        />
        <p className="mt-1 text-right text-xs text-muted">
          {notes.length}/{MAX_NOTES_LENGTH}
        </p>
      </div>

      {errorKey && (
        <p role="alert" className="rounded-xl border border-cherry-500/40 bg-cherry-600/10 px-4 py-3 text-sm text-cherry-300">
          {t(errorKey)}
        </p>
      )}

      <button type="button" onClick={onAnalyze} className="btn-primary w-full sm:w-auto">
        <Activity className="h-5 w-5" />
        {t('screen.analyze')}
      </button>
    </div>
  );
}
