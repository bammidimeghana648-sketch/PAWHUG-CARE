import { useState } from 'react';
import { CheckCircle2, Crosshair, Loader2, MapPin, Navigation, Pencil, ShieldCheck, Trash2 } from 'lucide-react';
import { useLanguage } from '@/i18n/LanguageContext';
import type { TranslationKey } from '@/i18n/english';
import {
  googleDirectionsUrl,
  googleSearchUrl,
  isValidLatitude,
  isValidLongitude,
  requestCurrentPosition,
  type LocationDraft,
} from '@/lib/location';
import MapPreview from '@/components/MapPreview';

type LocationPickerProps = {
  location: LocationDraft | null;
  onChange: (location: LocationDraft | null) => void;
};

const MAX_ADDRESS_LENGTH = 200;

export default function LocationPicker({ location, onChange }: LocationPickerProps) {
  const { t } = useLanguage();
  const [requesting, setRequesting] = useState(false);
  const [errorKey, setErrorKey] = useState<TranslationKey | null>(null);
  const [manualOpen, setManualOpen] = useState(false);
  const [manualAddress, setManualAddress] = useState(location?.kind === 'manual' ? location.address : '');
  const [adjusting, setAdjusting] = useState(false);
  const [latText, setLatText] = useState('');
  const [lngText, setLngText] = useState('');
  const [adjustError, setAdjustError] = useState(false);

  const useCurrentLocation = async () => {
    setRequesting(true);
    setErrorKey(null);
    const outcome = await requestCurrentPosition();
    setRequesting(false);

    if (outcome.ok) {
      onChange({ kind: 'gps', latitude: outcome.latitude, longitude: outcome.longitude, confirmed: false });
      setManualOpen(false);
      return;
    }
    if (outcome.reason === 'denied') {
      setErrorKey('check.permissionDenied');
      setManualOpen(true);
      return;
    }
    setErrorKey('check.locationError');
  };

  const saveManualAddress = () => {
    const address = manualAddress.trim();
    if (!address) return;
    onChange({ kind: 'manual', address, confirmed: true });
    setManualOpen(false);
    setErrorKey(null);
  };

  const startAdjusting = () => {
    if (location?.kind !== 'gps') return;
    setLatText(location.latitude.toFixed(6));
    setLngText(location.longitude.toFixed(6));
    setAdjustError(false);
    setAdjusting(true);
  };

  const applyAdjustment = () => {
    const latitude = Number(latText);
    const longitude = Number(lngText);
    if (!isValidLatitude(latitude) || !isValidLongitude(longitude) || latText.trim() === '' || lngText.trim() === '') {
      setAdjustError(true);
      return;
    }
    onChange({ kind: 'gps', latitude, longitude, confirmed: false });
    setAdjusting(false);
  };

  const confirmGps = () => {
    if (location?.kind === 'gps') onChange({ ...location, confirmed: true });
  };

  const removeLocation = () => {
    onChange(null);
    setAdjusting(false);
    setManualOpen(false);
    setErrorKey(null);
  };

  const explanation = (
    <div className="flex gap-3 rounded-2xl border border-violet-300/20 bg-violet-500/10 p-4">
      <ShieldCheck className="mt-0.5 h-5 w-5 shrink-0 text-violet-300" aria-hidden="true" />
      <p className="text-sm leading-relaxed text-ivory/85">{t('check.locationWhy')}</p>
    </div>
  );

  const manualForm = (
    <div className="space-y-3">
      <label className="block text-sm font-semibold text-ivory" htmlFor="manual-address">
        {t('check.manualLabel')}
      </label>
      <input
        id="manual-address"
        type="text"
        value={manualAddress}
        maxLength={MAX_ADDRESS_LENGTH}
        onChange={(event) => setManualAddress(event.target.value)}
        placeholder={t('check.manualPlaceholder')}
        className="field"
      />
      <div className="flex flex-wrap gap-3">
        <button type="button" onClick={saveManualAddress} disabled={!manualAddress.trim()} className="btn-primary">
          <CheckCircle2 className="h-5 w-5" />
          {t('check.saveAddress')}
        </button>
        {location && (
          <button type="button" onClick={() => setManualOpen(false)} className="btn-secondary">
            {t('common.close')}
          </button>
        )}
      </div>
    </div>
  );

  if (!location) {
    return (
      <div className="space-y-5">
        {explanation}
        <div className="flex flex-col gap-3 sm:flex-row">
          <button type="button" onClick={useCurrentLocation} disabled={requesting} className="btn-primary">
            {requesting ? <Loader2 className="h-5 w-5 animate-spin" /> : <Crosshair className="h-5 w-5" />}
            {requesting ? t('check.locating') : t('check.useLocation')}
          </button>
          {!manualOpen && (
            <button type="button" onClick={() => setManualOpen(true)} className="btn-secondary">
              <Pencil className="h-4 w-4" />
              {t('check.enterManually')}
            </button>
          )}
        </div>
        {errorKey && (
          <p role="alert" className="rounded-xl border border-cherry-500/40 bg-cherry-600/10 px-4 py-3 text-sm text-cherry-300">
            {t(errorKey)}
          </p>
        )}
        {manualOpen && <div className="animate-fadeUp rounded-2xl border border-white/10 bg-night-900/60 p-4">{manualForm}</div>}
      </div>
    );
  }

  const statusBadge = location.confirmed ? (
    <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-400/15 px-3 py-1 text-xs font-semibold text-emerald-300">
      <CheckCircle2 className="h-3.5 w-3.5" />
      {t('check.confirmed')}
    </span>
  ) : (
    <span className="inline-flex items-center gap-1.5 rounded-full bg-amber-400/15 px-3 py-1 text-xs font-semibold text-amber-200">
      {t('check.unconfirmed')}
    </span>
  );

  if (location.kind === 'manual') {
    return (
      <div className="animate-fadeUp space-y-5">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="flex min-w-0 gap-3">
            <MapPin className="mt-0.5 h-5 w-5 shrink-0 text-cherry-400" aria-hidden="true" />
            <div className="min-w-0">
              <p className="break-words font-semibold text-ivory">{location.address}</p>
              <p className="mt-1 text-sm text-muted">{t('check.noCoordinates')}</p>
            </div>
          </div>
          {statusBadge}
        </div>
        <div className="flex flex-wrap gap-3">
          <a href={googleSearchUrl(location.address)} target="_blank" rel="noopener noreferrer" className="btn-secondary">
            <Navigation className="h-4 w-4" />
            {t('check.directions')}
          </a>
          <button
            type="button"
            onClick={() => {
              setManualAddress(location.address);
              setManualOpen(true);
            }}
            className="btn-secondary"
          >
            <Pencil className="h-4 w-4" />
            {t('common.edit')}
          </button>
          <button type="button" onClick={removeLocation} className="inline-flex items-center justify-center gap-2 rounded-full border border-cherry-500/40 bg-cherry-600/10 px-5 py-2.5 font-semibold text-cherry-300 transition hover:bg-cherry-600/20">
            <Trash2 className="h-4 w-4" />
            {t('check.removeLocation')}
          </button>
        </div>
        {manualOpen && <div className="animate-fadeUp rounded-2xl border border-white/10 bg-night-900/60 p-4">{manualForm}</div>}
      </div>
    );
  }

  return (
    <div className="animate-fadeUp space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <MapPin className="h-5 w-5 shrink-0 text-cherry-400" aria-hidden="true" />
          <div>
            <p className="text-sm text-muted">{t('check.coordinates')}</p>
            <p className="font-mono text-sm text-ivory">
              {location.latitude.toFixed(5)}, {location.longitude.toFixed(5)}
            </p>
          </div>
        </div>
        {statusBadge}
      </div>

      <MapPreview latitude={location.latitude} longitude={location.longitude} />

      {adjusting && (
        <div className="animate-fadeUp grid gap-3 rounded-2xl border border-white/10 bg-night-900/60 p-4 sm:grid-cols-2">
          <label className="block text-sm text-muted">
            {t('check.latitude')}
            <input
              type="text"
              inputMode="decimal"
              value={latText}
              onChange={(event) => setLatText(event.target.value)}
              className="field mt-1.5 font-mono"
            />
          </label>
          <label className="block text-sm text-muted">
            {t('check.longitude')}
            <input
              type="text"
              inputMode="decimal"
              value={lngText}
              onChange={(event) => setLngText(event.target.value)}
              className="field mt-1.5 font-mono"
            />
          </label>
          {adjustError && (
            <p role="alert" className="text-sm text-cherry-300 sm:col-span-2">
              {t('check.invalidCoordinates')}
            </p>
          )}
          <div className="flex flex-wrap gap-3 sm:col-span-2">
            <button type="button" onClick={applyAdjustment} className="btn-primary">
              {t('common.done')}
            </button>
            <button type="button" onClick={() => setAdjusting(false)} className="btn-secondary">
              {t('common.close')}
            </button>
          </div>
        </div>
      )}

      <div className="flex flex-wrap gap-3">
        {!location.confirmed && (
          <button type="button" onClick={confirmGps} className="btn-primary">
            <CheckCircle2 className="h-5 w-5" />
            {t('check.confirmLocation')}
          </button>
        )}
        <a href={googleDirectionsUrl(location.latitude, location.longitude)} target="_blank" rel="noopener noreferrer" className="btn-secondary">
          <Navigation className="h-4 w-4" />
          {t('check.directions')}
        </a>
        {!adjusting && (
          <button type="button" onClick={startAdjusting} className="btn-secondary">
            <Pencil className="h-4 w-4" />
            {t('check.adjust')}
          </button>
        )}
        <button type="button" onClick={useCurrentLocation} disabled={requesting} className="btn-secondary">
          <Crosshair className="h-4 w-4" />
          {t('check.retryLocation')}
        </button>
        <button type="button" onClick={removeLocation} className="inline-flex items-center justify-center gap-2 rounded-full border border-cherry-500/40 bg-cherry-600/10 px-5 py-2.5 font-semibold text-cherry-300 transition hover:bg-cherry-600/20">
          <Trash2 className="h-4 w-4" />
          {t('check.removeLocation')}
        </button>
      </div>
    </div>
  );
}
