import { useState } from 'react';
import { Menu, RotateCw, X } from 'lucide-react';
import { useLanguage } from '@/i18n/LanguageContext';
import { LANGUAGES } from '@/i18n/languages';
import type { TranslationKey } from '@/i18n/english';
import type { Route } from '@/hooks/useHashRoute';
import Logo from '@/components/Logo';

const NAV_ITEMS: { route: Route; labelKey: TranslationKey }[] = [
  { route: 'home', labelKey: 'nav.home' },
  { route: 'check', labelKey: 'nav.check' },
  { route: 'report', labelKey: 'nav.report' },
  { route: 'reports', labelKey: 'nav.reports' },
  { route: 'settings', labelKey: 'nav.settings' },
  { route: 'about', labelKey: 'nav.about' },
];

type NavbarProps = {
  activeRoute: Route;
  onNavigate: (route: Route) => void;
};

export default function Navbar({ activeRoute, onNavigate }: NavbarProps) {
  const { t, language } = useLanguage();
  const [menuOpen, setMenuOpen] = useState(false);
  const currentLanguage = LANGUAGES.find((item) => item.code === language);

  const go = (route: Route) => {
    setMenuOpen(false);
    onNavigate(route);
  };

  return (
    <header className="sticky top-0 z-40 border-b border-white/10 bg-night-950/85 backdrop-blur-xl">
      <div className="mx-auto flex h-20 max-w-6xl items-center justify-between px-4 sm:px-6">
        <button
          type="button"
          onClick={() => go('home')}
          className="rounded-2xl transition hover:opacity-90"
          aria-label="PawHug home"
        >
          <Logo showName />
        </button>

        <nav className="hidden items-center gap-1 md:flex" aria-label="Main">
          {NAV_ITEMS.map((item) => (
            <button
              key={item.route}
              type="button"
              onClick={() => go(item.route)}
              aria-current={activeRoute === item.route ? 'page' : undefined}
              className={`rounded-full px-4 py-2 text-sm font-semibold transition duration-200 ${
                activeRoute === item.route
                  ? 'bg-white/10 text-ivory'
                  : 'text-muted hover:bg-white/5 hover:text-ivory'
              }`}
            >
              {t(item.labelKey)}
            </button>
          ))}
          <span className="ml-3 rounded-full border border-violet-300/30 bg-violet-500/10 px-3 py-1 text-xs font-semibold text-violet-300">
            {currentLanguage?.nativeName}
          </span>
          <button
            type="button"
            onClick={() => window.location.reload()}
            className="ml-2 inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-3 py-2 text-sm font-semibold text-ivory transition hover:bg-white/10"
          >
            <RotateCw className="h-4 w-4" aria-hidden="true" />
            {t('reports.refresh')}
          </button>
        </nav>

        <button
          type="button"
          onClick={() => setMenuOpen((open) => !open)}
          className="grid h-11 w-11 place-items-center rounded-full border border-white/15 bg-white/5 text-ivory transition hover:bg-white/10 md:hidden"
          aria-label={menuOpen ? t('nav.closeMenu') : t('nav.openMenu')}
          aria-expanded={menuOpen}
        >
          {menuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>

      {menuOpen && (
        <nav
          className="animate-fadeUp border-t border-white/10 bg-night-900/95 px-4 pb-4 pt-2 md:hidden"
          aria-label="Mobile"
        >
          {NAV_ITEMS.map((item) => (
            <button
              key={item.route}
              type="button"
              onClick={() => go(item.route)}
              aria-current={activeRoute === item.route ? 'page' : undefined}
              className={`block w-full rounded-2xl px-4 py-3 text-left text-base font-semibold transition ${
                activeRoute === item.route ? 'bg-white/10 text-ivory' : 'text-muted hover:bg-white/5 hover:text-ivory'
              }`}
            >
              {t(item.labelKey)}
            </button>
          ))}
        </nav>
      )}
    </header>
  );
}
