import { CheckCircle2, ExternalLink, LoaderCircle, LocateFixed, Trash2 } from 'lucide-react';
import { useLanguage } from '@/i18n/LanguageContext';
import type { TranslationKey } from '@/i18n/english';
import { googleMapsPointUrl } from '@/lib/location';

type ReportLocationFieldsProps = {
  locationText: string;
  latitude: number | null;
  longitude: number | null;
  error?: TranslationKey;
  locating: boolean;
  gpsMessage: TranslationKey | null;
  onLocationTextChange: (value: string) => void;
  onAttachGps: () => void;
  onClearGps: () => void;
};

export default function ReportLocationFields({
  locationText,
  latitude,
  longitude,
  error,
  locating,
  gpsMessage,
  onLocationTextChange,
  onAttachGps,
  onClearGps,
}: ReportLocationFieldsProps) {
  const { t } = useLanguage();
  const hasGps = latitude !== null && longitude !== null;

  return (
    <div className="space-y-5">
      <div>
        <label htmlFor="report-location" className="mb-2 block text-sm font-semibold text-ivory">
          {t('report.locationLabel')}
        </label>
        <input
          id="report-location"
          type="text"
          value={locationText}
          onChange={(event) => onLocationTextChange(event.target.value)}
          placeholder={t('report.locationPlaceholder')}
          aria-invalid={error ? true : undefined}
          className="field"
        />
        <p className="mt-2 text-sm text-muted">{t('report.locationHelp')}</p>
        {error && <p className="mt-2 text-sm text-cherry-300">{t(error)}</p>}
      </div>

      <div className="rounded-2xl border border-white/10 bg-night-900/60 p-4 sm:p-5">
        <p className="font-semibold text-ivory">{t('report.gpsTitle')}</p>
        <p className="mt-1 text-sm text-muted">{t('report.gpsHelp')}</p>

        {hasGps ? (
          <div className="mt-4 flex flex-wrap items-center gap-3">
            <span className="inline-flex items-center gap-2 rounded-full bg-emerald-400/15 px-3 py-1.5 text-sm font-semibold text-emerald-200">
              <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
              {t('report.locationAttached')}
              <span className="font-mono text-xs font-normal text-ivory/80">
                {latitude.toFixed(5)}, {longitude.toFixed(5)}
              </span>
            </span>
            <a
              href={googleMapsPointUrl(latitude, longitude)}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 text-sm font-semibold text-cherry-300 underline-offset-4 hover:underline"
            >
              <ExternalLink className="h-3.5 w-3.5" aria-hidden="true" />
              {t('report.openMap')}
            </a>
            <div className="flex flex-wrap gap-3">
              <button type="button" onClick={onAttachGps} disabled={locating} className="btn-secondary">
                {locating ? (
                  <LoaderCircle className="h-4 w-4 animate-spin" aria-hidden="true" />
                ) : (
                  <LocateFixed className="h-4 w-4" aria-hidden="true" />
                )}
                {t('report.gpsUpdate')}
              </button>
              <button
                type="button"
                onClick={onClearGps}
                className="inline-flex items-center justify-center gap-2 rounded-full border border-cherry-500/40 bg-cherry-600/10 px-5 py-2.5 font-semibold text-cherry-300 transition hover:bg-cherry-600/20"
              >
                <Trash2 className="h-4 w-4" aria-hidden="true" />
                {t('report.gpsRemove')}
              </button>
            </div>
          </div>
        ) : (
          <div className="mt-4 flex flex-wrap items-center gap-3">
            <button type="button" onClick={onAttachGps} disabled={locating} className="btn-secondary">
              {locating ? (
                <LoaderCircle className="h-4 w-4 animate-spin" aria-hidden="true" />
              ) : (
                <LocateFixed className="h-4 w-4" aria-hidden="true" />
              )}
              {t('report.useLocation')}
            </button>
            {gpsMessage && <span className="text-sm text-muted">{t(gpsMessage)}</span>}
          </div>
        )}
      </div>
    </div>
  );
}
