import { Check } from 'lucide-react';
import { LANGUAGES, type LanguageCode } from '@/i18n/languages';
import { useLanguage } from '@/i18n/LanguageContext';

type LanguageGridProps = {
  selected: LanguageCode | null;
  onSelect: (code: LanguageCode) => void;
};

export default function LanguageGrid({ selected, onSelect }: LanguageGridProps) {
  const { t } = useLanguage();

  return (
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
      {LANGUAGES.map((language, index) => {
        const isSelected = selected === language.code;
        return (
          <button
            key={language.code}
            type="button"
            onClick={() => onSelect(language.code)}
            aria-pressed={isSelected}
            style={{ animationDelay: `${index * 40}ms` }}
            className={`animate-fadeUp group relative flex min-h-[104px] flex-col items-start justify-between rounded-2xl border p-4 text-left transition duration-200 hover:-translate-y-0.5 ${
              isSelected
                ? 'border-cherry-400 bg-gradient-to-br from-cherry-600/30 to-wine-600/40 shadow-lg shadow-cherry-600/20'
                : 'border-white/10 bg-night-800/80 hover:border-violet-300/50 hover:bg-night-700/80'
            }`}
          >
            <span className="flex w-full items-start justify-between gap-2">
              <span className="text-xl font-bold text-ivory">{language.nativeName}</span>
              <span
                className={`grid h-6 w-6 shrink-0 place-items-center rounded-full border transition ${
                  isSelected ? 'border-cherry-400 bg-cherry-500 text-white' : 'border-white/25 text-transparent'
                }`}
                aria-hidden="true"
              >
                <Check className="h-3.5 w-3.5" />
              </span>
            </span>
            <span className="mt-3 flex flex-col gap-1">
              <span className="text-sm text-muted">{language.name}</span>
              <span
                className={`w-fit rounded-full px-2 py-0.5 text-[11px] font-semibold ${
                  language.hasTranslation ? 'bg-emerald-400/15 text-emerald-300' : 'bg-white/10 text-muted'
                }`}
              >
                {language.hasTranslation ? t('lang.fullTranslation') : t('lang.englishFallback')}
              </span>
            </span>
          </button>
        );
      })}
    </div>
  );
}
