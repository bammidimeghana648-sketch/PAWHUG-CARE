type LogoProps = {
  className?: string;
  showName?: boolean;
};

export default function Logo({ className = '', showName = false }: LogoProps) {
  return (
    <span className={`inline-flex items-center gap-3 ${className}`}>
      <span className="grid h-12 w-12 shrink-0 place-items-center overflow-hidden rounded-2xl bg-white shadow-lg shadow-black/30 ring-1 ring-white/20">
        <img src="/image.png" alt="PawHug logo" className="h-full w-full object-contain p-1" />
      </span>
      {showName && <span className="text-xl font-bold tracking-tight text-ivory">PawHug</span>}
    </span>
  );
}
