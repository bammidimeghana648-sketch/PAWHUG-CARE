import { useState, type FormEvent } from 'react';
import { LoaderCircle, Send } from 'lucide-react';
import { useLanguage } from '@/i18n/LanguageContext';
import type { TranslationKey } from '@/i18n/english';
import { requestCurrentPosition } from '@/lib/location';
import { draftFromCaseHandoff, type CaseHandoff } from '@/lib/reports/caseHandoff';
import { urgencyForSymptoms } from '@/lib/screening/analyzeAnimal';
import { SCREENING_CATEGORIES, type SymptomId } from '@/lib/screening/symptoms';
import { supabase } from '@/lib/supabase';
import { useObjectUrl } from '@/hooks/useObjectUrl';
import PhotoUploader from '@/components/PhotoUploader';
import ReportLocationFields from '@/components/ReportLocationFields';
import ReportScreeningFields from '@/components/ReportScreeningFields';
import {
  CONDITION_MAX,
  isRescueReport,
  RESCUE_PHOTO_BUCKET,
  resolveReportLocation,
  validateReportDraft,
  type ReportDraft,
  type ReportField,
  type RescueReport,
} from '@/lib/reports/reportModel';

type ReportFormProps = {
  prefill: CaseHandoff | null;
  onSubmitted: (report: RescueReport) => void;
};

const EMPTY_DRAFT: ReportDraft = {
  animalCategory: '',
  conditionSummary: '',
  locationText: '',
  latitude: null,
  longitude: null,
  symptoms: [],
};

export default function ReportForm({ prefill, onSubmitted }: ReportFormProps) {
  const { t } = useLanguage();
  const [draft, setDraft] = useState<ReportDraft>(() => (prefill ? draftFromCaseHandoff(prefill) : EMPTY_DRAFT));
  const [errors, setErrors] = useState<Partial<Record<ReportField, TranslationKey>>>({});
  const [submitError, setSubmitError] = useState<TranslationKey | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [locating, setLocating] = useState(false);
  const [locationKey, setLocationKey] = useState<TranslationKey | null>(null);
  const [photo, setPhoto] = useState<File | null>(prefill?.photo ?? null);
  const photoUrl = useObjectUrl(photo);

  const update = <K extends keyof ReportDraft>(field: K, value: ReportDraft[K]) => {
    setDraft((current) => ({ ...current, [field]: value }));
    setErrors((current) => ({ ...current, [field]: undefined }));
  };

  const toggleSymptom = (id: SymptomId) => {
    setDraft((current) => ({
      ...current,
      symptoms: current.symptoms.includes(id)
        ? current.symptoms.filter((item) => item !== id)
        : [...current.symptoms, id],
    }));
  };

  const attachLocation = async () => {
    setLocating(true);
    setLocationKey(null);
    const outcome = await requestCurrentPosition();
    setLocating(false);
    if (outcome.ok) {
      setDraft((current) => ({ ...current, latitude: outcome.latitude, longitude: outcome.longitude }));
      setLocationKey('report.locationAttached');
    } else {
      setDraft((current) => ({ ...current, latitude: null, longitude: null }));
      setLocationKey(outcome.reason === 'denied' ? 'report.locationDenied' : 'report.locationUnavailable');
    }
  };

  const clearLocation = () => {
    setDraft((current) => ({ ...current, latitude: null, longitude: null }));
    setLocationKey(null);
  };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setSubmitError(null);
    const nextErrors = validateReportDraft(draft);
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) return;

    setSubmitting(true);
    let photoPath: string | null = null;
    if (photo) {
      photoPath = `${crypto.randomUUID()}.${photo.type === 'image/png' ? 'png' : 'jpg'}`;
      const upload = await supabase.storage.from(RESCUE_PHOTO_BUCKET).upload(photoPath, photo, {
        contentType: photo.type,
        upsert: false,
      });
      if (upload.error) {
        setSubmitting(false);
        setSubmitError('report.errorPhoto');
        return;
      }
    }

    const { data, error } = await supabase
      .from('rescue_reports')
      .insert({
        animal_category: draft.animalCategory,
        condition_summary: draft.conditionSummary.trim(),
        location_text: resolveReportLocation(draft),
        latitude: draft.latitude,
        longitude: draft.longitude,
        photo_path: photoPath,
        screening_symptoms: draft.symptoms,
        screening_urgency: draft.symptoms.length > 0 ? urgencyForSymptoms(new Set(draft.symptoms)) : null,
        screened_at: prefill?.screenedAt ?? null,
      })
      .select();
    setSubmitting(false);

    const saved = Array.isArray(data) ? data[0] : undefined;
    if (error || !isRescueReport(saved)) {
      setSubmitError('report.errorSave');
      return;
    }
    setDraft(EMPTY_DRAFT);
    setPhoto(null);
    onSubmitted(saved);
  };

  const conditionCount = draft.conditionSummary.length;

  return (
    <form onSubmit={handleSubmit} noValidate className="space-y-7">
      {prefill && (
        <p role="status" className="rounded-xl border border-emerald-400/30 bg-emerald-400/10 px-4 py-3 text-sm text-emerald-100">
          {t('report.prefillNotice')} <span className="text-xs opacity-80">({new Date(prefill.screenedAt).toLocaleString()})</span>
        </p>
      )}
      <div>
        <label htmlFor="report-category" className="mb-2 block text-sm font-semibold text-ivory">
          {t('report.animalLabel')}
        </label>
        <select
          id="report-category"
          value={draft.animalCategory}
          onChange={(event) => update('animalCategory', event.target.value as ReportDraft['animalCategory'])}
          aria-invalid={errors.animalCategory ? true : undefined}
          className="field"
        >
          <option value="" disabled>
            {t('report.animalPlaceholder')}
          </option>
          {SCREENING_CATEGORIES.map((item) => (
            <option key={item.id} value={item.id} className="bg-night-900">
              {t(item.label)}
            </option>
          ))}
        </select>
        {errors.animalCategory && <FieldError messageKey={errors.animalCategory} />}
      </div>

      <div>
        <label htmlFor="report-condition" className="mb-2 block text-sm font-semibold text-ivory">
          {t('report.conditionLabel')}
        </label>
        <textarea
          id="report-condition"
          rows={4}
          maxLength={CONDITION_MAX}
          value={draft.conditionSummary}
          onChange={(event) => update('conditionSummary', event.target.value)}
          placeholder={t('report.conditionPlaceholder')}
          aria-invalid={errors.conditionSummary ? true : undefined}
          className="field resize-y"
        />
        <div className="mt-1 flex items-start justify-between gap-3">
          {errors.conditionSummary ? <FieldError messageKey={errors.conditionSummary} /> : <span />}
          <span className="shrink-0 text-xs text-muted">
            {conditionCount}/{CONDITION_MAX}
          </span>
        </div>
      </div>

      <ReportLocationFields
        locationText={draft.locationText}
        latitude={draft.latitude}
        longitude={draft.longitude}
        error={errors.locationText}
        locating={locating}
        gpsMessage={locationKey}
        onLocationTextChange={(value) => update('locationText', value)}
        onAttachGps={attachLocation}
        onClearGps={clearLocation}
      />

      <div>
        <ReportScreeningFields selected={draft.symptoms} onToggle={toggleSymptom} />
      </div>

      <div>
        <p className="mb-2 text-sm font-semibold text-ivory">{t('report.photoLabel')}</p>
        <PhotoUploader
          file={photo}
          previewUrl={photoUrl}
          onSelect={setPhoto}
          onRemove={() => setPhoto(null)}
        />
      </div>

      {submitError && (
        <p role="alert" className="rounded-xl border border-cherry-500/40 bg-cherry-600/10 px-4 py-3 text-sm text-cherry-300">
          {t(submitError)}
        </p>
      )}

      <button type="submit" disabled={submitting} className="btn-primary w-full sm:w-auto">
        {submitting ? (
          <LoaderCircle className="h-5 w-5 animate-spin" aria-hidden="true" />
        ) : (
          <Send className="h-5 w-5" aria-hidden="true" />
        )}
        {t('report.submit')}
      </button>
    </form>
  );
}

function FieldError({ messageKey }: { messageKey: TranslationKey }) {
  const { t } = useLanguage();
  return <p className="mt-2 text-sm text-cherry-300">{t(messageKey)}</p>;
}
