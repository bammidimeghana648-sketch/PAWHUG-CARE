import { useRef, useState, type ChangeEvent } from 'react';
import { Camera, ImagePlus, RefreshCw, Trash2, Upload } from 'lucide-react';
import { useLanguage } from '@/i18n/LanguageContext';
import type { TranslationKey } from '@/i18n/english';
import CameraCapture from '@/components/CameraCapture';

const ACCEPTED_TYPES = ['image/jpeg', 'image/png'];
const MAX_FILE_BYTES = 8 * 1024 * 1024;

type PhotoUploaderProps = {
  file: File | null;
  previewUrl: string | null;
  onSelect: (file: File) => void;
  onRemove: () => void;
};

const JPEG_SIGNATURE = [0xff, 0xd8, 0xff];
const PNG_SIGNATURE = [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a];

async function hasImageSignature(file: File) {
  const bytes = new Uint8Array(await file.slice(0, 8).arrayBuffer());
  const matches = (signature: number[]) => signature.every((byte, index) => bytes[index] === byte);
  return matches(JPEG_SIGNATURE) || matches(PNG_SIGNATURE);
}

async function validatePhotoFile(file: File): Promise<TranslationKey | null> {
  if (!ACCEPTED_TYPES.includes(file.type)) return 'check.photoTypeError';
  if (file.size > MAX_FILE_BYTES) return 'check.photoSizeError';
  if (file.size === 0) return 'check.photoReadError';
  if (!(await hasImageSignature(file))) return 'check.photoSignatureError';
  return null;
}

export default function PhotoUploader({ file, previewUrl, onSelect, onRemove }: PhotoUploaderProps) {
  const { t } = useLanguage();
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const uploadInputRef = useRef<HTMLInputElement>(null);
  const [errorKey, setErrorKey] = useState<TranslationKey | null>(null);
  const [cameraOpen, setCameraOpen] = useState(false);

  const acceptFile = async (selected: File) => {
    const problem = await validatePhotoFile(selected);
    if (problem) {
      setErrorKey(problem);
      return;
    }
    setErrorKey(null);
    onSelect(selected);
  };

  const handleFile = async (event: ChangeEvent<HTMLInputElement>) => {
    const selected = event.target.files?.[0];
    event.target.value = '';
    if (!selected) return;
    await acceptFile(selected);
  };

  const handleCapture = async (captured: File) => {
    setCameraOpen(false);
    await acceptFile(captured);
  };

  const openCamera = () => {
    if (typeof navigator.mediaDevices?.getUserMedia === 'function') {
      setCameraOpen(true);
      return;
    }
    cameraInputRef.current?.click();
  };
  const openUpload = () => uploadInputRef.current?.click();

  return (
    <div>
      <input
        ref={cameraInputRef}
        type="file"
        accept="image/jpeg,image/png"
        capture="environment"
        onChange={handleFile}
        className="hidden"
        aria-hidden="true"
        tabIndex={-1}
      />
      <input
        ref={uploadInputRef}
        type="file"
        accept="image/jpeg,image/png"
        onChange={handleFile}
        className="hidden"
        aria-hidden="true"
        tabIndex={-1}
      />

      {cameraOpen && <CameraCapture onCapture={handleCapture} onClose={() => setCameraOpen(false)} />}

      {file && previewUrl ? (
        <div className="animate-fadeUp">
          <div className="overflow-hidden rounded-2xl border border-white/10 bg-night-900">
            <img src={previewUrl} alt={t('check.photoTitle')} className="max-h-96 w-full object-contain" />
          </div>
          <p className="mt-3 truncate text-sm text-muted">{file.name}</p>
          <div className="mt-4 flex flex-wrap gap-3">
            <button type="button" onClick={openUpload} className="btn-secondary">
              <RefreshCw className="h-4 w-4" />
              {t('check.replacePhoto')}
            </button>
            <button
              type="button"
              onClick={onRemove}
              className="inline-flex items-center justify-center gap-2 rounded-full border border-cherry-500/40 bg-cherry-600/10 px-5 py-2.5 font-semibold text-cherry-300 transition hover:bg-cherry-600/20"
            >
              <Trash2 className="h-4 w-4" />
              {t('check.removePhoto')}
            </button>
          </div>
        </div>
      ) : (
        <div className="rounded-2xl border-2 border-dashed border-white/15 bg-night-900/60 p-6 text-center sm:p-10">
          <span className="mx-auto grid h-16 w-16 place-items-center rounded-2xl bg-white/10 text-ivory">
            <ImagePlus className="h-8 w-8" aria-hidden="true" />
          </span>
          <p className="mt-4 text-sm text-muted">{t('check.photoHint')}</p>
          <div className="mt-6 flex flex-col justify-center gap-3 sm:flex-row">
            <button type="button" onClick={openCamera} className="btn-primary">
              <Camera className="h-5 w-5" />
              {t('check.takePhoto')}
            </button>
            <button type="button" onClick={openUpload} className="btn-secondary">
              <Upload className="h-5 w-5" />
              {t('check.uploadPhoto')}
            </button>
          </div>
        </div>
      )}

      {errorKey && (
        <p role="alert" className="mt-3 rounded-xl border border-cherry-500/40 bg-cherry-600/10 px-4 py-3 text-sm text-cherry-300">
          {t(errorKey)}
        </p>
      )}
    </div>
  );
}
