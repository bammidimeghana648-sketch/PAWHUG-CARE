import { AlertTriangle } from 'lucide-react';
import { useLanguage } from '@/i18n/LanguageContext';
import { SYMPTOMS, type SymptomId, type Urgency } from '@/lib/screening/symptoms';
import { urgencyForSymptoms } from '@/lib/screening/analyzeAnimal';
import { URGENCY_KEYS, URGENCY_STYLES } from '@/components/ScreeningResult';

type ReportScreeningFieldsProps = {
  selected: SymptomId[];
  onToggle: (id: SymptomId) => void;
};

export default function ReportScreeningFields({ selected, onToggle }: ReportScreeningFieldsProps) {
  const { t } = useLanguage();
  const selectedSet = new Set(selected);
  const urgency: Urgency | null = selected.length > 0 ? urgencyForSymptoms(selectedSet) : null;

  return (
    <fieldset className="space-y-4">
      <legend className="text-sm font-semibold text-ivory">{t('report.screeningTitle')}</legend>
      <p className="text-sm text-muted">{t('report.screeningHelp')}</p>

      <div className="grid gap-2 sm:grid-cols-2">
        {SYMPTOMS.map((symptom) => {
          const checked = selectedSet.has(symptom.id);
          return (
            <label
              key={symptom.id}
              className={`flex cursor-pointer items-start gap-3 rounded-2xl border p-3.5 text-sm transition duration-200 ${
                checked
                  ? 'border-cherry-400/60 bg-cherry-600/15 text-ivory'
                  : 'border-white/10 bg-night-900/60 text-muted hover:border-white/25 hover:text-ivory'
              }`}
            >
              <input
                type="checkbox"
                checked={checked}
                onChange={() => onToggle(symptom.id)}
                className="mt-0.5 h-4 w-4 shrink-0 accent-cherry-500"
              />
              <span className="leading-snug">{t(symptom.label)}</span>
            </label>
          );
        })}
      </div>

      {urgency === null ? (
        <p className="text-sm text-muted">{t('report.screeningNone')}</p>
      ) : (
        <div className={`rounded-2xl border p-4 ${URGENCY_STYLES[urgency]}`} role="status">
          <p className="text-xs font-semibold uppercase tracking-widest opacity-80">{t('screen.urgencyLabel')}</p>
          <p className="mt-1 text-lg font-bold">{t(URGENCY_KEYS[urgency])}</p>
          {urgency === 'emergency' && (
            <p className="mt-2 flex items-start gap-2 text-sm font-semibold">
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
              {t('screen.emergencyBanner')}
            </p>
          )}
        </div>
      )}
      <p className="text-xs text-muted">{t('screen.disclaimer')}</p>
    </fieldset>
  );
}
