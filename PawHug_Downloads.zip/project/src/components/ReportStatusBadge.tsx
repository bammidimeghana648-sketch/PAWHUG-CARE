import { useLanguage } from '@/i18n/LanguageContext';
import type { TranslationKey } from '@/i18n/english';
import type { ReportStatus } from '@/lib/reports/reportModel';

const STATUS_KEYS: Record<ReportStatus, TranslationKey> = {
  submitted: 'report.status.submitted',
  under_review: 'report.status.under_review',
  resolved: 'report.status.resolved',
};

const STATUS_STYLES: Record<ReportStatus, string> = {
  submitted: 'border-amber-300/40 bg-amber-300/10 text-amber-100',
  under_review: 'border-sky-300/40 bg-sky-300/10 text-sky-100',
  resolved: 'border-emerald-400/40 bg-emerald-400/10 text-emerald-100',
};

export default function ReportStatusBadge({ status }: { status: ReportStatus }) {
  const { t } = useLanguage();
  return (
    <span className={`inline-flex items-center rounded-full border px-3 py-1 text-xs font-semibold ${STATUS_STYLES[status]}`}>
      {t(STATUS_KEYS[status])}
    </span>
  );
}
