import Logo from '@/components/Logo';
import { useLanguage } from '@/i18n/LanguageContext';

export default function Footer() {
  const { t } = useLanguage();

  return (
    <footer className="border-t border-white/10 bg-night-950/80">
      <div className="mx-auto flex max-w-6xl flex-col items-center gap-4 px-4 py-8 text-center sm:px-6 md:flex-row md:justify-between md:text-left">
        <Logo showName />
        <p className="max-w-xl text-xs leading-relaxed text-muted">{t('home.disclaimer')}</p>
      </div>
    </footer>
  );
}
