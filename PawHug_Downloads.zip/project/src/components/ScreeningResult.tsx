import type { ReactNode } from 'react';
import { Ban, Eye, FilePenLine, Info, ListChecks, ShieldAlert, Stethoscope, Users } from 'lucide-react';
import { useLanguage } from '@/i18n/LanguageContext';
import type { TranslationKey } from '@/i18n/english';
import type { ScreeningResult as Result } from '@/lib/screening/analyzeAnimal';
import type { Urgency } from '@/lib/screening/symptoms';

export const URGENCY_KEYS: Record<Urgency, TranslationKey> = {
  general: 'screen.urgency.general',
  vet: 'screen.urgency.vet',
  urgent: 'screen.urgency.urgent',
  emergency: 'screen.urgency.emergency',
};

export const URGENCY_STYLES: Record<Urgency, string> = {
  general: 'border-emerald-400/40 bg-emerald-400/10 text-emerald-200',
  vet: 'border-amber-300/40 bg-amber-300/10 text-amber-100',
  urgent: 'border-orange-400/50 bg-orange-500/15 text-orange-100',
  emergency: 'border-cherry-400 bg-cherry-600 text-white',
};

type ScreeningResultProps = {
  result: Result;
  photoUrl: string | null;
  onReportCase: () => void;
};

function ResultSection({ icon: Icon, title, children }: { icon: typeof Info; title: string; children: ReactNode }) {
  return (
    <section className="border-t border-white/10 pt-6">
      <h3 className="flex items-center gap-2 text-lg font-semibold text-ivory">
        <Icon className="h-5 w-5 text-cherry-400" aria-hidden="true" />
        {title}
      </h3>
      <div className="mt-3 text-sm leading-relaxed text-muted">{children}</div>
    </section>
  );
}

function BulletList({ items }: { items: string[] }) {
  return (
    <ul className="list-disc space-y-2 pl-5">
      {items.map((item) => (
        <li key={item}>{item}</li>
      ))}
    </ul>
  );
}

export default function ScreeningResult({ result, photoUrl, onReportCase }: ScreeningResultProps) {
  const { t } = useLanguage();
  const isEmergency = result.urgency === 'emergency';

  return (
    <article className="card animate-fadeUp space-y-6" aria-labelledby="screening-result-title">
      <header className="space-y-4">
        <p className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 text-ivory">
          <Info className="h-3.5 w-3.5" aria-hidden="true" />
          {t('screen.demoBanner')}
        </p>
        <h2 id="screening-result-title" className="text-2xl font-bold text-ivory">
          {t('screen.resultTitle')}
        </h2>
        <div
          className={`rounded-2xl border p-4 ${result.needsMoreInfo ? 'border-white/15 bg-white/5 text-ivory' : URGENCY_STYLES[result.urgency]}`}
          role={isEmergency ? 'alert' : undefined}
        >
          <p className="text-xs font-semibold uppercase tracking-widest opacity-80">{t('screen.urgencyLabel')}</p>
          <p className="mt-1 text-lg font-bold">{t(result.needsMoreInfo ? 'screen.urgency.unclear' : URGENCY_KEYS[result.urgency])}</p>
          {isEmergency && <p className="mt-2 text-sm font-semibold">{t('screen.emergencyBanner')}</p>}
        </div>
      </header>

      {photoUrl && (
        <figure>
          <img src={photoUrl} alt={t('screen.uploadedPhoto')} className="max-h-80 w-full rounded-2xl object-contain bg-night-900" />
          <figcaption className="mt-2 text-sm text-muted">{t('screen.photoNote')}</figcaption>
        </figure>
      )}

      <ResultSection icon={Eye} title={t('screen.observations')}>
        {result.observations.length > 0 ? <BulletList items={result.observations.map((key) => t(key))} /> : <p>{t('screen.noObservations')}</p>}
        {result.ownerNotes && <p className="mt-4 rounded-xl bg-white/5 p-3 italic">“{result.ownerNotes}”</p>}
      </ResultSection>

      {result.concerns.length > 0 && (
        <ResultSection icon={ShieldAlert} title={t('screen.concerns')}>
          <BulletList items={result.concerns.map((key) => t(key))} />
        </ResultSection>
      )}

      <ResultSection icon={ListChecks} title={t('screen.immediate')}>
        <BulletList items={result.immediateSteps.map((key) => t(key))} />
      </ResultSection>

      <ResultSection icon={Ban} title={t('screen.avoid')}>
        <BulletList items={result.avoidSteps.map((key) => t(key))} />
      </ResultSection>

      <ResultSection icon={Users} title={t('screen.isolation')}>
        <p>{t(result.isolation)}</p>
      </ResultSection>

      <ResultSection icon={Stethoscope} title={t('screen.vetWhen')}>
        <BulletList items={result.vetWarnings.map((key) => t(key))} />
      </ResultSection>

      <ResultSection icon={Eye} title={t('screen.safeApproach')}>
        <BulletList items={result.safeApproach.map((key) => t(key))} />
        <p className="mt-4 rounded-xl bg-white/5 p-3">{t(result.categoryNote)}</p>
      </ResultSection>

      {result.observations.length > 0 && (
        <section className="space-y-4 rounded-2xl border border-cherry-400/40 bg-cherry-600/10 p-5">
          <p className="text-sm leading-relaxed text-ivory">{t('report.caseHelp')}</p>
          {isEmergency && <p className="text-sm font-semibold text-cherry-200">{t('report.caseEmergency')}</p>}
          <button type="button" onClick={onReportCase} className="btn-primary w-full sm:w-auto">
            <FilePenLine className="h-5 w-5" aria-hidden="true" />
            {t('report.caseButton')}
          </button>
        </section>
      )}

      <p className="rounded-2xl border border-emerald-400/30 bg-emerald-400/10 p-4 text-sm font-semibold leading-relaxed text-emerald-100">
        {t('screen.disclaimer')}
      </p>
    </article>
  );
}
