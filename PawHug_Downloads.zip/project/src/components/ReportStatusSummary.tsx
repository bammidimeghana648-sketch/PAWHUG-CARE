import { useLanguage } from '@/i18n/LanguageContext';
import type { TranslationKey } from '@/i18n/english';
import type { ReportStatus } from '@/lib/reports/reportModel';

type ReportStatusSummaryProps = {
  total: number;
  counts: Record<ReportStatus, number>;
};

const CARDS: { key: ReportStatus | 'total'; labelKey: TranslationKey; accent: string }[] = [
  { key: 'total', labelKey: 'reports.total', accent: 'text-ivory' },
  { key: 'submitted', labelKey: 'report.status.submitted', accent: 'text-amber-200' },
  { key: 'under_review', labelKey: 'report.status.under_review', accent: 'text-sky-200' },
  { key: 'resolved', labelKey: 'report.status.resolved', accent: 'text-emerald-200' },
];

export default function ReportStatusSummary({ total, counts }: ReportStatusSummaryProps) {
  const { t } = useLanguage();
  return (
    <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
      {CARDS.map((card) => (
        <div key={card.key} className="card p-5">
          <p className="text-xs font-semibold uppercase tracking-widest text-muted">{t(card.labelKey)}</p>
          <p className={`mt-2 text-4xl font-bold ${card.accent}`}>
            {card.key === 'total' ? total : counts[card.key]}
          </p>
        </div>
      ))}
    </div>
  );
}
