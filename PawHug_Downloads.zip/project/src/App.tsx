import { useEffect, useState } from 'react';
import Footer from '@/components/Footer';
import Navbar from '@/components/Navbar';
import { useHashRoute, type Route } from '@/hooks/useHashRoute';
import { useLanguage } from '@/i18n/LanguageContext';
import AboutPage from '@/pages/AboutPage';
import CheckAnimalPage from '@/pages/CheckAnimalPage';
import HomePage from '@/pages/HomePage';
import LanguageSelectPage from '@/pages/LanguageSelectPage';
import ReportPage from '@/pages/ReportPage';
import type { CaseHandoff } from '@/lib/reports/caseHandoff';
import ReportsPage from '@/pages/ReportsPage';
import SettingsPage from '@/pages/SettingsPage';

function renderPage(
  route: Route,
  navigate: (route: Route) => void,
  caseHandoff: CaseHandoff | null,
  onReportCase: (handoff: CaseHandoff) => void,
) {
  switch (route) {
    case 'check':
      return <CheckAnimalPage onReportCase={onReportCase} />;
    case 'report':
      return <ReportPage handoff={caseHandoff} />;
    case 'reports':
      return <ReportsPage />;
    case 'settings':
      return <SettingsPage />;
    case 'about':
      return <AboutPage />;
    case 'home':
      return <HomePage onNavigate={navigate} />;
  }
}

export default function App() {
  const { language } = useLanguage();
  const { route, navigate } = useHashRoute();
  const [caseHandoff, setCaseHandoff] = useState<CaseHandoff | null>(null);

  useEffect(() => {
    if (route !== 'report') setCaseHandoff(null);
  }, [route]);

  const reportCase = (handoff: CaseHandoff) => {
    setCaseHandoff(handoff);
    navigate('report');
  };

  if (!language) {
    return <LanguageSelectPage />;
  }

  return (
    <div className="flex min-h-screen flex-col">
      <Navbar activeRoute={route} onNavigate={navigate} />
      <main className="flex-1">{renderPage(route, navigate, caseHandoff, reportCase)}</main>
      <Footer />
    </div>
  );
}
