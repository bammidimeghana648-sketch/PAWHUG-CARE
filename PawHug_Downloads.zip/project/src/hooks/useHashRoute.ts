import { useCallback, useEffect, useState } from 'react';

export type Route = 'home' | 'check' | 'report' | 'reports' | 'settings' | 'about';

const ROUTES: readonly Route[] = ['home', 'check', 'report', 'reports', 'settings', 'about'];

function routeFromHash(hash: string): Route {
  const name = hash.replace(/^#\/?/, '');
  return ROUTES.includes(name as Route) ? (name as Route) : 'home';
}

export function useHashRoute() {
  const [route, setRouteState] = useState<Route>(() => routeFromHash(window.location.hash));

  useEffect(() => {
    const onHashChange = () => setRouteState(routeFromHash(window.location.hash));
    window.addEventListener('hashchange', onHashChange);
    return () => window.removeEventListener('hashchange', onHashChange);
  }, []);

  const navigate = useCallback((next: Route) => {
    const target = next === 'home' ? '' : `#${next}`;
    if (window.location.hash !== target) {
      window.location.hash = target;
    }
    window.scrollTo({ top: 0 });
  }, []);

  return { route, navigate };
}
