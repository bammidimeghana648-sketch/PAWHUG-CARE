# Project memory

## Product intent & audience

- **PawHug AI Animal Rescue Assistant**: multilingual responsive web app for animal rescue coordination.
- Core features: AI health screening, rescue report management, nearby vet locator, volunteer coordination.
- Audience: rescuers, volunteers, vet staff, general public reporting animals in need.

## Brand personality & voice

- Compassionate, urgent, reliable, community-oriented.
- Tone: clear and actionable, never clinical or bureaucratic.

## Visual design & UX direction

- Vite + React + Tailwind CSS; Lucide React icons; `@/` import alias maps to `src/`.
- Fully responsive, production-quality, non-cookie-cutter UI.
- Map/location feature: migrated from OpenStreetMap embed (blocked by browser) to Google Maps embed (no API key needed).
- Directions links use Google Maps and remain as fallback if map embed is blocked.
- Rescue report form includes an "Address or nearby landmark" text field for manual address entry.
- GPS coordinates now link to Google Maps in two places: report form ("Open in Google Maps" link) and case cards ("View on Google Maps" link) for cases that have coordinates.

## Decisions, constraints & rationale

- OpenStreetMap iframe embed was blank because the browser refused the connection — not a missing key or code bug.
- Switched map provider to Google Maps embed to avoid requiring any API key or network change.
- Google Maps links added to report form and case cards for direct navigation to exact GPS coordinates.
- Build and type-check pass; visual confirmation in a live browser still pending.
- No additional UI/icon/theme packages to be installed beyond the template defaults.
- App currently receives raw GPS coordinates only (e.g., 16.96, 82.21) with no reverse-geocoding to convert them to street/area names.
- Reverse-geocoding (coordinate → address) not yet implemented; would require a server-side function or third-party API.

## Open questions & assumptions

- User's network may also block Google Maps embed; directions button is the fallback if so.
- Map accuracy depends on coordinates provided in rescue reports — no geolocation auto-detect confirmed yet.
- Multilingual support scope and languages not yet defined.
- AI health screening backend/model choice not yet discussed.
- Reverse-geocoding service choice pending; user was asked whether to build automatic address lookup (may face same network blocking as map embeds).