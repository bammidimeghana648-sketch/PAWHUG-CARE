/*
# Create rescue reports table

1. New Tables
- `rescue_reports`
  - `id` (uuid, primary key)
  - `reference` (text, unique, auto-generated like PH-1A2B3C4D for citizens to track a case)
  - `animal_category` (text: dog, cat, cow, buffalo, pig, bird, other)
  - `condition_summary` (text, 10 to 500 characters, what the reporter sees)
  - `location_text` (text, 3 to 200 characters, where the animal is)
  - `latitude` / `longitude` (double precision, optional, from the reporter's device)
  - `status` (text: submitted, under_review, resolved; new reports start as submitted)
  - `created_at` (timestamptz)

2. Security
- Row level security enabled.
- Anonymous and signed-in visitors can read reports (public tracking dashboard).
- Anonymous and signed-in visitors can insert reports, but only with status "submitted".
- No update or delete access is granted to the app. Status changes are made by staff directly in the database.

3. Notes
- The app has no sign-in, so policies target both anon and authenticated roles.
- No personal contact details are collected, so public reads expose no personal data.
*/

CREATE TABLE IF NOT EXISTS rescue_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  reference text NOT NULL UNIQUE DEFAULT 'PH-' || upper(substring(replace(gen_random_uuid()::text, '-', ''), 1, 8)),
  animal_category text NOT NULL CHECK (animal_category IN ('dog', 'cat', 'cow', 'buffalo', 'pig', 'bird', 'other')),
  condition_summary text NOT NULL CHECK (char_length(condition_summary) BETWEEN 10 AND 500),
  location_text text NOT NULL CHECK (char_length(location_text) BETWEEN 3 AND 200),
  latitude double precision CHECK (latitude IS NULL OR (latitude BETWEEN -90 AND 90)),
  longitude double precision CHECK (longitude IS NULL OR (longitude BETWEEN -180 AND 180)),
  status text NOT NULL DEFAULT 'submitted' CHECK (status IN ('submitted', 'under_review', 'resolved')),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS rescue_reports_status_idx ON rescue_reports (status);
CREATE INDEX IF NOT EXISTS rescue_reports_created_at_idx ON rescue_reports (created_at DESC);

ALTER TABLE rescue_reports ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT ON rescue_reports TO anon, authenticated;

DROP POLICY IF EXISTS "anon_select_rescue_reports" ON rescue_reports;
CREATE POLICY "anon_select_rescue_reports" ON rescue_reports FOR SELECT
TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_rescue_reports" ON rescue_reports;
CREATE POLICY "anon_insert_rescue_reports" ON rescue_reports FOR INSERT
TO anon, authenticated WITH CHECK (status = 'submitted');
