/*
# Add preliminary health screening to rescue reports

1. Modified Table
- `rescue_reports`
- `screening_urgency` (text, nullable): the preliminary urgency level from the reporter's symptom check: general, vet, urgent or emergency. Null for reports made without a symptom check.
- `screening_symptoms` (text array, default empty): the symptom ids the reporter ticked.

2. Security
- No change to row level security or grants. Existing table-level INSERT grant already covers new columns, and the insert policy still requires status = 'submitted'.

3. Important Notes
- Existing reports keep null urgency and an empty symptom list.
- The screening is a rule-based preliminary guide, not a diagnosis.
*/

ALTER TABLE rescue_reports ADD COLUMN IF NOT EXISTS screening_urgency text;
ALTER TABLE rescue_reports ADD COLUMN IF NOT EXISTS screening_symptoms text[] NOT NULL DEFAULT '{}';

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'rescue_reports_screening_urgency_check'
  ) THEN
    ALTER TABLE rescue_reports
      ADD CONSTRAINT rescue_reports_screening_urgency_check
      CHECK (screening_urgency IS NULL OR screening_urgency IN ('general', 'vet', 'urgent', 'emergency'));
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'rescue_reports_screening_symptoms_check'
  ) THEN
    ALTER TABLE rescue_reports
      ADD CONSTRAINT rescue_reports_screening_symptoms_check
      CHECK (cardinality(screening_symptoms) <= 13);
  END IF;
END $$;
