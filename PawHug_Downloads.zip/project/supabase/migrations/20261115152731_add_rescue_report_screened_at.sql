/*
# Link rescue reports to the animal check that prompted them

1. Modified Table
- `rescue_reports`
- `screened_at` (timestamptz, nullable): when the reporter ran the animal check that led to this report. Null for reports made without a check.

2. Security
- No change to row level security or grants. The existing table-level grants and insert policy already cover this column.

3. Important Notes
- Existing reports keep a null screening time.
*/

ALTER TABLE rescue_reports ADD COLUMN IF NOT EXISTS screened_at timestamptz;
