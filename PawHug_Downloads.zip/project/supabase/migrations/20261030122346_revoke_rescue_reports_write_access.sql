/*
# Remove update and delete access from rescue reports

1. Modified Tables
- `rescue_reports`: anonymous and signed-in visitors no longer hold UPDATE or DELETE privileges.

2. Security
- Only SELECT and INSERT remain granted to anon and authenticated, matching the policies.
- Status changes and removals are done by staff directly in the database.

3. Notes
- No data is changed or removed by this migration.
*/

REVOKE UPDATE, DELETE, TRUNCATE, REFERENCES, TRIGGER ON rescue_reports FROM anon, authenticated;
