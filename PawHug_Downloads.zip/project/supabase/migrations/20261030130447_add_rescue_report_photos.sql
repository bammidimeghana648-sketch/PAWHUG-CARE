/*
# Add photo uploads to rescue reports

1. New Storage
- Private bucket `rescue-photos` holding one photo per report.
- Accepts JPEG and PNG only, up to 8 MB per file.

2. Modified Tables
- `rescue_reports`: new optional column `photo_path` storing the file location inside the bucket.

3. Security
- The bucket is private. Photos are shown through short-lived signed links, not permanent public URLs.
- Anonymous and signed-in visitors can upload to this bucket and read its files (needed to create signed links).
- No update or delete access is granted to the app for photos or report photo paths.

4. Notes
- Existing reports are unchanged; their photo_path stays empty.
- The bucket enforces type and size limits; the app also checks the file's real content before uploading.
*/

INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('rescue-photos', 'rescue-photos', false, 8388608, ARRAY['image/jpeg', 'image/png'])
ON CONFLICT (id) DO NOTHING;

DROP POLICY IF EXISTS "anon_insert_rescue_photos" ON storage.objects;
CREATE POLICY "anon_insert_rescue_photos" ON storage.objects FOR INSERT
TO anon, authenticated
WITH CHECK (bucket_id = 'rescue-photos');

DROP POLICY IF EXISTS "anon_select_rescue_photos" ON storage.objects;
CREATE POLICY "anon_select_rescue_photos" ON storage.objects FOR SELECT
TO anon, authenticated
USING (bucket_id = 'rescue-photos');

ALTER TABLE rescue_reports ADD COLUMN IF NOT EXISTS photo_path text;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'rescue_reports_photo_path_length'
  ) THEN
    ALTER TABLE rescue_reports
      ADD CONSTRAINT rescue_reports_photo_path_length
      CHECK (photo_path IS NULL OR char_length(photo_path) BETWEEN 1 AND 120);
  END IF;
END $$;
